//OV5670_tables.c
/*****************************************************************************/
/*!
 *  \file        OV5670_tables.c \n
 *  \version     1.0 \n
 *  \author      Meinicke \n
 *  \brief       Image-sensor-specific tables and other
 *               constant values/structures for OV13850. \n
 *
 *  \revision    $Revision: 803 $ \n
 *               $Author: $ \n
 *               $Date: 2010-02-26 16:35:22 +0100 (Fr, 26 Feb 2010) $ \n
 *               $Id: OV13850_tables.c 803 2010-02-26 15:35:22Z  $ \n
 */
/*  This is an unpublished work, the copyright in which vests in Silicon Image
 *  GmbH. The information contained herein is the property of Silicon Image GmbH
 *  and is supplied without liability for errors or omissions. No part may be
 *  reproduced or used expect as authorized by contract or other written
 *  permission. Copyright(c) Silicon Image GmbH, 2009, all rights reserved.
 */
/*****************************************************************************/
/*
#include "stdinc.h"

#if( OV5670_DRIVER_USAGE == USE_CAM_DRV_EN )
*/


#include <ebase/types.h>
#include <ebase/trace.h>
#include <ebase/builtins.h>

#include <common/return_codes.h>

#include "isi.h"
#include "isi_iss.h"
#include "isi_priv.h"
#include "OV5670_MIPI_priv.h"


/*****************************************************************************
 * DEFINES
 *****************************************************************************/


/*****************************************************************************
 * GLOBALS
 *****************************************************************************/

// Image sensor register settings default values taken from data sheet OV13850_DS_1.1_SiliconImage.pdf.
// The settings may be altered by the code in IsiSetupSensor.

//two lane
const IsiRegDescription_t OV5670_g_aRegDescription_twolane[] =
{
#if 0 //Application note
	{0x0103, 0x01,"",eReadWrite,}, //software reset
	//{0x0000, 0x05, "0x0100", eDelay}, //delay 5m,
	{0x0100, 0x00,"",eReadWrite,}, // software standby
	{0x0300, 0x04,"",eReadWrite,}, // PLL
	{0x0301, 0x00,"",eReadWrite,}, //
	{0x0302, 0x69,"",eReadWrite,}, // MIPI bit rate 840Mbps/lane
	{0x0303, 0x00,"",eReadWrite,}, //
	{0x0304, 0x03,"",eReadWrite,}, //
	{0x0305, 0x01,"",eReadWrite,}, //
	{0x0306, 0x01,"",eReadWrite,}, //
	{0x030a, 0x00,"",eReadWrite,}, //
	{0x030b, 0x00,"",eReadWrite,}, //
	{0x030c, 0x00,"",eReadWrite,}, //
	{0x030d, 0x1e,"",eReadWrite,}, //
	{0x030e, 0x00,"",eReadWrite,}, //
	{0x030f, 0x06,"",eReadWrite,}, //
	{0x0312, 0x01,"",eReadWrite,}, // PLL
	{0x3000, 0x00,"",eReadWrite,}, // Fsin/Vsync input
	{0x3002, 0x21,"",eReadWrite,}, // ULPM output
	{0x3005, 0xf0,"",eReadWrite,}, // sclk_psram on, sclk_syncfifo on
	{0x3007, 0x00,"",eReadWrite,}, //
	{0x3015, 0x0f,"",eReadWrite,}, // npump clock div = 1, disable Ppumu_clk
	{0x3018, 0x32,"",eReadWrite,}, // MIPI 2 lane
	{0x301a, 0xf0,"",eReadWrite,}, // sclk_stb on, sclk_ac on, slck_tc on
	{0x301b, 0xf0,"",eReadWrite,}, // sclk_blc on, sclk_isp on, sclk_testmode on, sclk_vfifo on
	{0x301c, 0xf0,"",eReadWrite,}, // sclk_mipi on, sclk_dpcm on, sclk_otp on
	{0x301d, 0xf0,"",eReadWrite,}, // sclk_asram_tst on, sclk_grp on, sclk_bist on,
	{0x301e, 0xf0,"",eReadWrite,}, // sclk_ilpwm on, sclk_lvds on, sclk-vfifo on, sclk_mipi on,
	{0x3030, 0x00,"",eReadWrite,}, // sclk normal, pclk normal
	{0x3031, 0x0a,"",eReadWrite,}, // 10-bit mode
	{0x303c, 0xff,"",eReadWrite,}, // reserved
	{0x303e, 0xff,"",eReadWrite,}, // reserved
	{0x3040, 0xf0,"",eReadWrite,}, // sclk_isp_fc_en, sclk_fc-en, sclk_tpm_en, sclk_fmt_en
	{0x3041, 0x00,"",eReadWrite,}, // reserved
	{0x3042, 0xf0,"",eReadWrite,}, // reserved
	{0x3106, 0x11,"",eReadWrite,}, // sclk_div = 1, sclk_pre_div = 1
	{0x3500, 0x00,"",eReadWrite,}, // exposure H
	{0x3501, 0x3d,"",eReadWrite,}, // exposure M
	{0x3502, 0x00,"",eReadWrite,}, // exposure L
	{0x3503, 0x04,"",eReadWrite,}, // gain no delay, use sensor gain
	{0x3504, 0x03,"",eReadWrite,}, // exposure manual, gain manual
	{0x3505, 0x83,"",eReadWrite,}, // sensor gain fixed bit
	{0x3508, 0x04,"",eReadWrite,}, // gain H
	{0x3509, 0x00,"",eReadWrite,}, // gain L
	{0x350e, 0x04,"",eReadWrite,}, // short digital gain H
	{0x350f, 0x00,"",eReadWrite,}, // short digital gain L
	{0x3510, 0x00,"",eReadWrite,}, // short exposure H
	{0x3511, 0x02,"",eReadWrite,}, // short exposure M
	{0x3512, 0x00,"",eReadWrite,}, // short exposure L
	{0x3601, 0xc8,"",eReadWrite,}, // analog control
	{0x3610, 0x88,"",eReadWrite,}, //
	{0x3612, 0x48,"",eReadWrite,}, //
	{0x3614, 0x5b,"",eReadWrite,}, //
	{0x3615, 0x96,"",eReadWrite,}, //
	{0x3621, 0xd0,"",eReadWrite,}, //
	{0x3622, 0x00,"",eReadWrite,}, //
	{0x3623, 0x00,"",eReadWrite,}, //
	{0x3633, 0x13,"",eReadWrite,}, //
	{0x3634, 0x13,"",eReadWrite,}, //
	{0x3635, 0x13,"",eReadWrite,}, //
	{0x3636, 0x13,"",eReadWrite,}, //
	{0x3645, 0x13,"",eReadWrite,}, //
	{0x3646, 0x82,"",eReadWrite,}, //
	{0x3650, 0x00,"",eReadWrite,}, //
	{0x3652, 0xff,"",eReadWrite,}, //
	{0x3655, 0x20,"",eReadWrite,}, //
	{0x3656, 0xff,"",eReadWrite,}, //
	{0x365a, 0xff,"",eReadWrite,}, //
	
	{0x365e, 0xff,"",eReadWrite,}, //
	{0x3668, 0x00,"",eReadWrite,}, //
	{0x366a, 0x07,"",eReadWrite,}, //
	{0x366e, 0x08,"",eReadWrite,}, //
	{0x366d, 0x00,"",eReadWrite,}, //
	{0x366f, 0x80,"",eReadWrite,}, // analog control
	{0x3700, 0x28,"",eReadWrite,}, // sensor control
	{0x3701, 0x10,"",eReadWrite,}, //
	{0x3702, 0x3a,"",eReadWrite,}, //
	{0x3703, 0x19,"",eReadWrite,}, //
	{0x3704, 0x10,"",eReadWrite,}, //
	{0x3705, 0x00,"",eReadWrite,}, //
	{0x3706, 0x66,"",eReadWrite,}, //
	{0x3707, 0x08,"",eReadWrite,}, //
	{0x3708, 0x34,"",eReadWrite,}, //
	{0x3709, 0x40,"",eReadWrite,}, //
	{0x370a, 0x01,"",eReadWrite,}, //
	{0x370b, 0x1b,"",eReadWrite,}, //
	{0x3714, 0x24,"",eReadWrite,}, //
	{0x371a, 0x3e,"",eReadWrite,}, //
	{0x3733, 0x00,"",eReadWrite,}, //
	{0x3734, 0x00,"",eReadWrite,}, //
	{0x373a, 0x05,"",eReadWrite,}, //
	{0x373b, 0x06,"",eReadWrite,}, //
	{0x373c, 0x0a,"",eReadWrite,}, //
	{0x373f, 0xa0,"",eReadWrite,}, //
	{0x3755, 0x00,"",eReadWrite,}, //
	{0x3758, 0x00,"",eReadWrite,}, //
	{0x375b, 0x0e,"",eReadWrite,}, //
	{0x3766, 0x5f,"",eReadWrite,}, //
	{0x3768, 0x00,"",eReadWrite,}, //
	{0x3769, 0x22,"",eReadWrite,}, //
	{0x3773, 0x08,"",eReadWrite,}, //
	{0x3774, 0x1f,"",eReadWrite,}, //
	{0x3776, 0x06,"",eReadWrite,}, //
	{0x37a0, 0x88,"",eReadWrite,}, //
	{0x37a1, 0x5c,"",eReadWrite,}, //
	{0x37a7, 0x88,"",eReadWrite,}, //
	{0x37a8, 0x70,"",eReadWrite,}, //
	{0x37aa, 0x88,"",eReadWrite,}, //
	{0x37ab, 0x48,"",eReadWrite,}, //
	{0x37b3, 0x66,"",eReadWrite,}, //
	{0x37c2, 0x04,"",eReadWrite,}, //
	{0x37c5, 0x00,"",eReadWrite,}, //
	{0x37c8, 0x00,"",eReadWrite,}, // sensor control
	
	{0x3800, 0x00,"",eReadWrite,}, // x addr start H
	{0x3801, 0x0c,"",eReadWrite,}, // x addr start L
	{0x3802, 0x00,"",eReadWrite,}, // y addr start H
	{0x3803, 0x04,"",eReadWrite,}, // y addr start L
	{0x3804, 0x0a,"",eReadWrite,}, // x addr end H
	{0x3805, 0x33,"",eReadWrite,}, // x addr end L
	{0x3806, 0x07,"",eReadWrite,}, // y addr end H
	{0x3807, 0xa3,"",eReadWrite,}, // y addr end L
	{0x3808, 0x05,"",eReadWrite,}, // x output size H
	{0x3809, 0x10,"",eReadWrite,}, // x outout size L
	{0x380a, 0x03,"",eReadWrite,}, // y output size H
	{0x380b, 0xc0,"",eReadWrite,}, // y output size L
	{0x380c, 0x06,"",eReadWrite,}, // HTS H
	{0x380d, 0x90,"",eReadWrite,}, // HTS L
	{0x380e, 0x03,"",eReadWrite,}, // VTS H
	{0x380f, 0xfc,"",eReadWrite,}, // VTS L
	{0x3811, 0x04,"",eReadWrite,}, // ISP x win L
	{0x3813, 0x02,"",eReadWrite,}, // ISP y win L
	{0x3814, 0x03,"",eReadWrite,}, // x inc odd
	{0x3815, 0x01,"",eReadWrite,}, // x inc even
	{0x3816, 0x00,"",eReadWrite,}, // vsync start H
	{0x3817, 0x00,"",eReadWrite,}, // vsync star L
	{0x3818, 0x00,"",eReadWrite,}, // vsync end H
	{0x3819, 0x00,"",eReadWrite,}, // vsync end L
	{0x3820, 0x90,"",eReadWrite,}, // vsyn48_blc on, vflip off
	{0x3821, 0x47,"",eReadWrite,}, // hsync_en_o, mirror on, dig_bin on
	{0x3822, 0x48,"",eReadWrite,}, // addr0_num[3:1]=0x02, ablc_num[5:1]=0x08
	{0x3826, 0x00,"",eReadWrite,}, // r_rst_fsin H
	{0x3827, 0x08,"",eReadWrite,}, // r_rst_fsin L
	{0x382a, 0x03,"",eReadWrite,}, // y inc odd
	{0x382b, 0x01,"",eReadWrite,}, // y inc even
	{0x3830, 0x08,"",eReadWrite,}, //
	{0x3836, 0x02,"",eReadWrite,}, //
	{0x3837, 0x00,"",eReadWrite,}, //
	{0x3838, 0x10,"",eReadWrite,}, //
	{0x3841, 0xff,"",eReadWrite,}, //
	{0x3846, 0x48,"",eReadWrite,}, //
	{0x3861, 0x00,"",eReadWrite,}, //
	{0x3862, 0x04,"",eReadWrite,}, //
	{0x3863, 0x06,"",eReadWrite,}, //
	{0x3a11, 0x01,"",eReadWrite,}, //
	{0x3a12, 0x78,"",eReadWrite,}, //
	{0x3b00, 0x00,"",eReadWrite,}, // strobe
	{0x3b02, 0x00,"",eReadWrite,}, //
	{0x3b03, 0x00,"",eReadWrite,}, //
	
	{0x3b04, 0x00,"",eReadWrite,}, //
	{0x3b05, 0x00,"",eReadWrite,}, // strobe
	{0x3c00, 0x89,"",eReadWrite,}, //
	{0x3c01, 0xab,"",eReadWrite,}, //
	{0x3c02, 0x01,"",eReadWrite,}, //
	{0x3c03, 0x00,"",eReadWrite,}, //
	{0x3c04, 0x00,"",eReadWrite,}, //
	{0x3c05, 0x03,"",eReadWrite,}, //
	{0x3c06, 0x00,"",eReadWrite,}, //
	{0x3c07, 0x05,"",eReadWrite,}, //
	{0x3c0c, 0x00,"",eReadWrite,}, //
	{0x3c0d, 0x00,"",eReadWrite,}, //
	{0x3c0e, 0x00,"",eReadWrite,}, //
	{0x3c0f, 0x00,"",eReadWrite,}, //
	{0x3c40, 0x00,"",eReadWrite,}, //
	{0x3c41, 0xa3,"",eReadWrite,}, //
	{0x3c43, 0x7d,"",eReadWrite,}, //
	{0x3c45, 0xd7,"",eReadWrite,}, //
	{0x3c47, 0xfc,"",eReadWrite,}, //
	{0x3c50, 0x05,"",eReadWrite,}, //
	{0x3c52, 0xaa,"",eReadWrite,}, //
	{0x3c54, 0x71,"",eReadWrite,}, //
	{0x3c56, 0x80,"",eReadWrite,}, //
	{0x3d85, 0x17,"",eReadWrite,}, //
	{0x3f03, 0x00,"",eReadWrite,}, // PSRAM
	{0x3f0a, 0x00,"",eReadWrite,}, //
	{0x3f0b, 0x00,"",eReadWrite,}, // PSRAM
	{0x4001, 0x60,"",eReadWrite,}, // BLC, K enable
	{0x4009, 0x05,"",eReadWrite,}, // BLC, black line end line
	{0x4020, 0x00,"",eReadWrite,}, // BLC, offset compensation th000
	{0x4021, 0x00,"",eReadWrite,}, // BLC, offset compensation K000
	{0x4022, 0x00,"",eReadWrite,}, //
	{0x4023, 0x00,"",eReadWrite,}, //
	{0x4024, 0x00,"",eReadWrite,}, //
	{0x4025, 0x00,"",eReadWrite,}, //
	{0x4026, 0x00,"",eReadWrite,}, //
	{0x4027, 0x00,"",eReadWrite,}, //
	{0x4028, 0x00,"",eReadWrite,}, //
	{0x4029, 0x00,"",eReadWrite,}, //
	{0x402a, 0x00,"",eReadWrite,}, //
	{0x402b, 0x00,"",eReadWrite,}, //
	{0x402c, 0x00,"",eReadWrite,}, //
	{0x402d, 0x00,"",eReadWrite,}, //
	{0x402e, 0x00,"",eReadWrite,}, //
	{0x402f, 0x00,"",eReadWrite,}, //
	
	{0x4040, 0x00,"",eReadWrite,}, //
	{0x4041, 0x03,"",eReadWrite,}, //
	{0x4042, 0x00,"",eReadWrite,}, //
	{0x4043, 0x7A,"",eReadWrite,}, // 1/1.05 x (0x80)
	{0x4044, 0x00,"",eReadWrite,}, //
	{0x4045, 0x7A,"",eReadWrite,}, //
	{0x4046, 0x00,"",eReadWrite,}, //
	{0x4047, 0x7A,"",eReadWrite,}, //
	{0x4048, 0x00,"",eReadWrite,}, // BLC, kcoef_r_man H
	{0x4049, 0x7A,"",eReadWrite,}, // BLC, kcoef_r_man L
	{0x4303, 0x00,"",eReadWrite,}, //
	{0x4307, 0x30,"",eReadWrite,}, //
	{0x4500, 0x58,"",eReadWrite,}, //
	{0x4501, 0x04,"",eReadWrite,}, //
	{0x4502, 0x48,"",eReadWrite,}, //
	{0x4503, 0x10,"",eReadWrite,}, //
	{0x4508, 0x55,"",eReadWrite,}, //
	{0x4509, 0x55,"",eReadWrite,}, //
	{0x450a, 0x00,"",eReadWrite,}, //
	{0x450b, 0x00,"",eReadWrite,}, //
	{0x4600, 0x00,"",eReadWrite,}, //
	{0x4601, 0x81,"",eReadWrite,}, //
	{0x4700, 0xa4,"",eReadWrite,}, //
	{0x4800, 0x4c,"",eReadWrite,}, // MIPI conrol
	{0x4816, 0x53,"",eReadWrite,}, // emb_dt
	{0x481f, 0x40,"",eReadWrite,}, // clock_prepare_min
	{0x4837, 0x13,"",eReadWrite,}, // MIPI global timing
	{0x5000, 0x56,"",eReadWrite,}, // dcblc_en, awb_gain_en, bc_en, wc_en
	{0x5001, 0x01,"",eReadWrite,}, // blc_en
	{0x5002, 0x28,"",eReadWrite,}, // otp_dpc_en
	{0x5004, 0x0c,"",eReadWrite,}, // ISP size auto control enable
	{0x5006, 0x0c,"",eReadWrite,}, //
	{0x5007, 0xe0,"",eReadWrite,}, //
	{0x5008, 0x01,"",eReadWrite,}, //
	{0x5009, 0xb0,"",eReadWrite,}, //
	{0x5901, 0x00,"",eReadWrite,}, // VAP
	{0x5a01, 0x00,"",eReadWrite,}, // WINC x start offset H
	{0x5a03, 0x00,"",eReadWrite,}, // WINC x start offset L
	{0x5a04, 0x0c,"",eReadWrite,}, // WINC y start offset H
	{0x5a05, 0xe0,"",eReadWrite,}, // WINC y start offset L
	{0x5a06, 0x09,"",eReadWrite,}, // WINC window width H
	{0x5a07, 0xb0,"",eReadWrite,}, // WINC window width L
	{0x5a08, 0x06,"",eReadWrite,}, // WINC window height H
	{0x5e00, 0x00,"",eReadWrite,}, // WINC window height L
	{0x3734, 0x40,"",eReadWrite,}, //; Improve HFPN
	
	{0x5b00, 0x01,"",eReadWrite,}, //; [2:0] otp start addr[10:8]
	{0x5b01, 0x10,"",eReadWrite,}, //; [7:0] otp start addr[7:0]
	{0x5b02, 0x01,"",eReadWrite,}, //; [2:0] otp end addr[10:8]
	{0x5b03, 0xdb,"",eReadWrite,}, //; [7:0] otp end addr[7:0]
	{0x3d8c, 0x71,"",eReadWrite,}, // Header address high byte
	{0x3d8d, 0xea,"",eReadWrite,}, // Header address low byte
	{0x4017, 0x10,"",eReadWrite,}, // threshold = 4LSB for Binning sum format.
	{0x3618, 0x2a,"",eReadWrite,}, //
	{0x5780, 0x3e,"",eReadWrite,}, //
	{0x5781, 0x0f,"",eReadWrite,}, //
	{0x5782, 0x44,"",eReadWrite,}, //
	{0x5783, 0x02,"",eReadWrite,}, //
	{0x5784, 0x01,"",eReadWrite,}, //
	{0x5785, 0x01,"",eReadWrite,}, //
	{0x5786, 0x00,"",eReadWrite,}, //
	{0x5787, 0x04,"",eReadWrite,}, //
	{0x5788, 0x02,"",eReadWrite,}, //
	{0x5789, 0x0f,"",eReadWrite,}, //
	{0x578a, 0xfd,"",eReadWrite,}, //
	{0x578b, 0xf5,"",eReadWrite,}, //
	{0x578c, 0xf5,"",eReadWrite,}, //
	{0x578d, 0x03,"",eReadWrite,}, //
	{0x578e, 0x08,"",eReadWrite,}, //
	{0x578f, 0x0c,"",eReadWrite,}, //
	{0x5790, 0x08,"",eReadWrite,}, //
	{0x5791, 0x06,"",eReadWrite,}, //
	{0x5792, 0x00,"",eReadWrite,}, //
	{0x5793, 0x52,"",eReadWrite,}, //
	{0x5794, 0xa3,"",eReadWrite,}, //
	{0x3503, 0x30,"",eReadWrite,}, // exposure gain/exposure delay not used
	{0x3002, 0x61,"",eReadWrite,}, //[6]ULPM output enable
	{0x3010, 0x40,"",eReadWrite,}, //[6]enable ULPM as GPIO controlled by register
	{0x300d, 0x00,"",eReadWrite,}, //[6]ULPM output low (if 1=> high)
	{0x5045, 0x05,"",eReadWrite,}, //[2] enable MWB manual bias
	{0x5048, 0x10,"",eReadWrite,}, // MWB manual bias; need to be the same with 0x4003 BLC target.
	//{0x0100, 0x01,"",eReadWrite,},
	/* 2592x1944 30fps 24M MCLK 2lane 840Mbps/lane */
	{0x0100, 0x00,"",eReadWrite,},
	{0x3501, 0x7b,"",eReadWrite,}, // exposure M
	{0x3623, 0x00,"",eReadWrite,}, // analog control
	{0x366e, 0x10,"",eReadWrite,}, // analog control
	{0x370b, 0x1b,"",eReadWrite,}, // sensor control
	{0x3808, 0x0a,"",eReadWrite,}, // x output size H
	{0x3809, 0x20,"",eReadWrite,}, // x output size L
	{0x380a, 0x07,"",eReadWrite,}, // y outout size H
	{0x380b, 0x98,"",eReadWrite,}, // y output size L
	{0x380c, 0x06,"",eReadWrite,}, // HTS H
	{0x380d, 0x90,"",eReadWrite,}, // HTS L
	{0x380e, 0x07,"",eReadWrite,}, // VTS H
	{0x380f, 0xf6,"",eReadWrite,}, // VTS L
	{0x3814, 0x01,"",eReadWrite,}, // x inc odd
	{0x3820, 0x80,"",eReadWrite,}, // vsyn48_blc on, vflip off
	{0x3821, 0x46,"",eReadWrite,}, // hsync_en_o, mirror on, dig_bin on
	{0x382a, 0x01,"",eReadWrite,}, // y inc odd
	{0x4009, 0x0d,"",eReadWrite,}, // BLC, black line end line
	{0x4502, 0x40,"",eReadWrite,},
	{0x4508, 0xaa,"",eReadWrite,},
	{0x4509, 0xaa,"",eReadWrite,},
	{0x450a, 0x00,"",eReadWrite,},
	{0x4600, 0x01,"",eReadWrite,},
	{0x4601, 0x03,"",eReadWrite,},
	{0x4017, 0x08,"",eReadWrite,}, //BLC, offset trigger threshold
	//{0x0100, 0x01,"",eReadWrite,},
	{0x0000 ,0x00,"eTableEnd",eTableEnd}

#else   //OV support series
	{0x0103, 0x01,"",eReadWrite,},
	//{0x0000, 0x05, "0x0100", eDelay}, //delay 5m,
	{0x0100, 0x00,"",eReadWrite,},
	{0x0300, 0x04,"",eReadWrite,},
	{0x0301, 0x00,"",eReadWrite,},
	{0x0302, 0x69,"",eReadWrite,}, ////78// MIPI bit rate 960Mbps/lane -> 840Mbps/lane
	{0x0303, 0x00,"",eReadWrite,},
	{0x0304, 0x03,"",eReadWrite,},
	{0x0305, 0x01,"",eReadWrite,},
	{0x0306, 0x01,"",eReadWrite,},
	{0x030a, 0x00,"",eReadWrite,},
	{0x030b, 0x00,"",eReadWrite,},
	{0x030c, 0x00,"",eReadWrite,},
	{0x030d, 0x1e,"",eReadWrite,},
	{0x030e, 0x00,"",eReadWrite,},
	{0x030f, 0x06,"",eReadWrite,},
	{0x0312, 0x01,"",eReadWrite,},
	{0x3000, 0x00,"",eReadWrite,},
	{0x3002, 0x21,"",eReadWrite,},
	{0x3005, 0xf0,"",eReadWrite,},
	{0x3007, 0x00,"",eReadWrite,},
	{0x3015, 0x0f,"",eReadWrite,},
	{0x3018, 0x32,"",eReadWrite,},
	{0x301a, 0xf0,"",eReadWrite,},
	{0x301b, 0xf0,"",eReadWrite,},
	{0x301c, 0xf0,"",eReadWrite,},
	{0x301d, 0xf0,"",eReadWrite,},
	{0x301e, 0xf0,"",eReadWrite,},
	{0x3030, 0x00,"",eReadWrite,},
	{0x3031, 0x0a,"",eReadWrite,},
	{0x303c, 0xff,"",eReadWrite,},
	{0x303e, 0xff,"",eReadWrite,},
	{0x3040, 0xf0,"",eReadWrite,},
	{0x3041, 0x00,"",eReadWrite,},
	{0x3042, 0xf0,"",eReadWrite,},
	{0x3106, 0x11,"",eReadWrite,},
	{0x3500, 0x00,"",eReadWrite,},
	{0x3501, 0x7b,"",eReadWrite,},
	{0x3502, 0x00,"",eReadWrite,},
	{0x3503, 0x04,"",eReadWrite,},
	{0x3504, 0x03,"",eReadWrite,},
	{0x3505, 0x83,"",eReadWrite,},
	{0x3508, 0x04,"",eReadWrite,},
	{0x3509, 0x00,"",eReadWrite,},
	{0x350e, 0x04,"",eReadWrite,},
	{0x350f, 0x00,"",eReadWrite,},
	{0x3510, 0x00,"",eReadWrite,},
	{0x3511, 0x02,"",eReadWrite,},
	{0x3512, 0x00,"",eReadWrite,},
	{0x3601, 0xc8,"",eReadWrite,},
	{0x3610, 0x88,"",eReadWrite,},
	{0x3612, 0x48,"",eReadWrite,},
	{0x3614, 0x5b,"",eReadWrite,},
	{0x3615, 0x96,"",eReadWrite,},
	{0x3621, 0xd0,"",eReadWrite,},
	{0x3622, 0x00,"",eReadWrite,},
	{0x3623, 0x00,"",eReadWrite,},
	{0x3633, 0x13,"",eReadWrite,},
	{0x3634, 0x13,"",eReadWrite,},
	{0x3635, 0x13,"",eReadWrite,},
	{0x3636, 0x13,"",eReadWrite,},
	{0x3645, 0x13,"",eReadWrite,},
	{0x3646, 0x82,"",eReadWrite,},
	{0x3650, 0x00,"",eReadWrite,},
	{0x3652, 0xff,"",eReadWrite,},
	{0x3655, 0x20,"",eReadWrite,},
	{0x3656, 0xff,"",eReadWrite,},
	{0x365a, 0xff,"",eReadWrite,},
	{0x365e, 0xff,"",eReadWrite,},
	{0x3668, 0x00,"",eReadWrite,},
	{0x366a, 0x07,"",eReadWrite,},
	{0x366e, 0x10,"",eReadWrite,},
	{0x366d, 0x00,"",eReadWrite,},
	{0x366f, 0x80,"",eReadWrite,},
	{0x3700, 0x28,"",eReadWrite,},
	{0x3701, 0x10,"",eReadWrite,},
	{0x3702, 0x3a,"",eReadWrite,},
	{0x3703, 0x19,"",eReadWrite,},
	{0x3704, 0x10,"",eReadWrite,},
	{0x3705, 0x00,"",eReadWrite,},
	{0x3706, 0x66,"",eReadWrite,},
	{0x3707, 0x08,"",eReadWrite,},
	{0x3708, 0x34,"",eReadWrite,},
	{0x3709, 0x40,"",eReadWrite,},
	{0x370a, 0x01,"",eReadWrite,},
	{0x370b, 0x1b,"",eReadWrite,},
	{0x3714, 0x24,"",eReadWrite,},
	{0x371a, 0x3e,"",eReadWrite,},
	{0x3733, 0x00,"",eReadWrite,},
	{0x3734, 0x00,"",eReadWrite,},
	{0x373a, 0x05,"",eReadWrite,},
	{0x373b, 0x06,"",eReadWrite,},
	{0x373c, 0x0a,"",eReadWrite,},
	{0x373f, 0xa0,"",eReadWrite,},
	{0x3755, 0x00,"",eReadWrite,},
	{0x3758, 0x00,"",eReadWrite,},
	{0x375b, 0x0e,"",eReadWrite,},
	{0x3766, 0x5f,"",eReadWrite,},
	{0x3768, 0x00,"",eReadWrite,},
	{0x3769, 0x22,"",eReadWrite,},
	{0x3773, 0x08,"",eReadWrite,},
	{0x3774, 0x1f,"",eReadWrite,},
	{0x3776, 0x06,"",eReadWrite,},
	{0x37a0, 0x88,"",eReadWrite,},
	{0x37a1, 0x5c,"",eReadWrite,},
	{0x37a7, 0x88,"",eReadWrite,},
	{0x37a8, 0x70,"",eReadWrite,},
	{0x37aa, 0x88,"",eReadWrite,},
	{0x37ab, 0x48,"",eReadWrite,},
	{0x37b3, 0x66,"",eReadWrite,},
	{0x37c2, 0x04,"",eReadWrite,},
	{0x37c5, 0x00,"",eReadWrite,},
	{0x37c8, 0x00,"",eReadWrite,},
	{0x3800, 0x00,"",eReadWrite,},
	{0x3801, 0x0c,"",eReadWrite,},
	{0x3802, 0x00,"",eReadWrite,},
	{0x3803, 0x04,"",eReadWrite,},
	{0x3804, 0x0a,"",eReadWrite,},
	{0x3805, 0x33,"",eReadWrite,},
	{0x3806, 0x07,"",eReadWrite,},
	{0x3807, 0xa3,"",eReadWrite,},
	{0x3808, 0x0a,"",eReadWrite,},
	{0x3809, 0x20,"",eReadWrite,},
	{0x380a, 0x07,"",eReadWrite,},
	{0x380b, 0x98,"",eReadWrite,},
	{0x380c, 0x06,"",eReadWrite,},
	{0x380d, 0x90,"",eReadWrite,},//8c
	{0x380e, 0x07,"",eReadWrite,},
	{0x380f, 0xb8,"",eReadWrite,},
	{0x3811, 0x04,"",eReadWrite,},
	{0x3813, 0x02,"",eReadWrite,},
	{0x3814, 0x01,"",eReadWrite,},
	{0x3815, 0x01,"",eReadWrite,},
	{0x3816, 0x00,"",eReadWrite,},
	{0x3817, 0x00,"",eReadWrite,},
	{0x3818, 0x00,"",eReadWrite,},
	{0x3819, 0x00,"",eReadWrite,},
	{0x3820, 0x80,"",eReadWrite,},
	{0x3821, 0x46,"",eReadWrite,},
	{0x3822, 0x48,"",eReadWrite,},
	{0x3826, 0x00,"",eReadWrite,},
	{0x3827, 0x08,"",eReadWrite,},
	{0x382a, 0x01,"",eReadWrite,},
	{0x382b, 0x01,"",eReadWrite,},
	{0x3830, 0x08,"",eReadWrite,},
	{0x3836, 0x02,"",eReadWrite,},
	{0x3837, 0x00,"",eReadWrite,},
	{0x3838, 0x10,"",eReadWrite,},
	{0x3841, 0xff,"",eReadWrite,},
	{0x3846, 0x48,"",eReadWrite,},
	{0x3861, 0x00,"",eReadWrite,},
	{0x3862, 0x04,"",eReadWrite,},
	{0x3863, 0x06,"",eReadWrite,},
	{0x3a11, 0x01,"",eReadWrite,},
	{0x3a12, 0x78,"",eReadWrite,},
	{0x3b00, 0x00,"",eReadWrite,},
	{0x3b02, 0x00,"",eReadWrite,},
	{0x3b03, 0x00,"",eReadWrite,},
	{0x3b04, 0x00,"",eReadWrite,},
	{0x3b05, 0x00,"",eReadWrite,},
	{0x3c00, 0x89,"",eReadWrite,},
	{0x3c01, 0xab,"",eReadWrite,},
	{0x3c02, 0x01,"",eReadWrite,},
	{0x3c03, 0x00,"",eReadWrite,},
	{0x3c04, 0x00,"",eReadWrite,},
	{0x3c05, 0x03,"",eReadWrite,},
	{0x3c06, 0x00,"",eReadWrite,},
	{0x3c07, 0x05,"",eReadWrite,},
	{0x3c0c, 0x00,"",eReadWrite,},
	{0x3c0d, 0x00,"",eReadWrite,},
	{0x3c0e, 0x00,"",eReadWrite,},
	{0x3c0f, 0x00,"",eReadWrite,},
	{0x3c40, 0x00,"",eReadWrite,},
	{0x3c41, 0xa3,"",eReadWrite,},
	{0x3c43, 0x7d,"",eReadWrite,},
	{0x3c45, 0xd7,"",eReadWrite,},
	{0x3c47, 0xfc,"",eReadWrite,},
	{0x3c50, 0x05,"",eReadWrite,},
	{0x3c52, 0xaa,"",eReadWrite,},
	{0x3c54, 0x71,"",eReadWrite,},
	{0x3c56, 0x80,"",eReadWrite,},
	{0x3d85, 0x17,"",eReadWrite,},
	{0x3f03, 0x00,"",eReadWrite,},
	{0x3f0a, 0x00,"",eReadWrite,},
	{0x3f0b, 0x00,"",eReadWrite,},
	{0x4001, 0x60,"",eReadWrite,},
	{0x4009, 0x0d,"",eReadWrite,},
	{0x4020, 0x00,"",eReadWrite,},
	{0x4021, 0x00,"",eReadWrite,},
	{0x4022, 0x00,"",eReadWrite,},
	{0x4023, 0x00,"",eReadWrite,},
	{0x4024, 0x00,"",eReadWrite,},
	{0x4025, 0x00,"",eReadWrite,},
	{0x4026, 0x00,"",eReadWrite,},
	{0x4027, 0x00,"",eReadWrite,},
	{0x4028, 0x00,"",eReadWrite,},
	{0x4029, 0x00,"",eReadWrite,},
	{0x402a, 0x00,"",eReadWrite,},
	{0x402b, 0x00,"",eReadWrite,},
	{0x402c, 0x00,"",eReadWrite,},
	{0x402d, 0x00,"",eReadWrite,},
	{0x402e, 0x00,"",eReadWrite,},
	{0x402f, 0x00,"",eReadWrite,},
	{0x4040, 0x00,"",eReadWrite,},
	{0x4041, 0x03,"",eReadWrite,},
	{0x4042, 0x00,"",eReadWrite,},
	{0x4043, 0x7A,"",eReadWrite,}, // 1/1.05 x (0x80)
	{0x4044, 0x00,"",eReadWrite,},
	{0x4045, 0x7A,"",eReadWrite,},
	{0x4046, 0x00,"",eReadWrite,},
	{0x4047, 0x7A,"",eReadWrite,},
	{0x4048, 0x00,"",eReadWrite,},
	{0x4049, 0x7A,"",eReadWrite,},
	{0x4303, 0x00,"",eReadWrite,},
	{0x4307, 0x30,"",eReadWrite,},
	{0x4500, 0x58,"",eReadWrite,},
	{0x4501, 0x04,"",eReadWrite,},
	{0x4502, 0x40,"",eReadWrite,},
	{0x4503, 0x10,"",eReadWrite,},
	{0x4508, 0xaa,"",eReadWrite,},
	{0x4509, 0xaa,"",eReadWrite,},
	{0x450a, 0x00,"",eReadWrite,},
	{0x450b, 0x00,"",eReadWrite,},
	{0x4600, 0x01,"",eReadWrite,},
	{0x4601, 0x03,"",eReadWrite,},
	{0x4700, 0xa4,"",eReadWrite,},
	{0x4800, 0x4c,"",eReadWrite,},
	{0x4816, 0x53,"",eReadWrite,},
	{0x481f, 0x40,"",eReadWrite,},
	{0x4837, 0x13,"",eReadWrite,},//11// MIPI global timing
	{0x5000, 0x56,"",eReadWrite,},
	{0x5001, 0x01,"",eReadWrite,},
	{0x5002, 0x28,"",eReadWrite,},
	{0x5004, 0x0c,"",eReadWrite,},
	{0x5006, 0x0c,"",eReadWrite,},
	{0x5007, 0xe0,"",eReadWrite,},
	{0x5008, 0x01,"",eReadWrite,},
	{0x5009, 0xb0,"",eReadWrite,},
	{0x5901, 0x00,"",eReadWrite,},
	{0x5a01, 0x00,"",eReadWrite,},
	{0x5a03, 0x00,"",eReadWrite,},
	{0x5a04, 0x0c,"",eReadWrite,},
	{0x5a05, 0xe0,"",eReadWrite,},
	{0x5a06, 0x09,"",eReadWrite,},
	{0x5a07, 0xb0,"",eReadWrite,},
	{0x5a08, 0x06,"",eReadWrite,},
	{0x5e00, 0x00,"",eReadWrite,},
	{0x3734, 0x40,"",eReadWrite,},
	{0x5b00, 0x01,"",eReadWrite,},
	{0x5b01, 0x10,"",eReadWrite,},
	{0x5b02, 0x01,"",eReadWrite,},
	{0x5b03, 0xdb,"",eReadWrite,},
	{0x3d8c, 0x71,"",eReadWrite,},
	{0x3d8d, 0xea,"",eReadWrite,},
	{0x4017, 0x08,"",eReadWrite,},
	{0x3618, 0x2a,"",eReadWrite,},
	
	//Ping
	//Strong DPC1.53
	{0x5780, 0x3e,"",eReadWrite,},
	{0x5781, 0x0f,"",eReadWrite,},
	{0x5782, 0x44,"",eReadWrite,},
	{0x5783, 0x02,"",eReadWrite,},
	{0x5784, 0x01,"",eReadWrite,},
	{0x5785, 0x01,"",eReadWrite,},
	{0x5786, 0x00,"",eReadWrite,},
	{0x5787, 0x04,"",eReadWrite,},
	{0x5788, 0x02,"",eReadWrite,},
	{0x5789, 0x0f,"",eReadWrite,},
	{0x578a, 0xfd,"",eReadWrite,},
	{0x578b, 0xf5,"",eReadWrite,},
	{0x578c, 0xf5,"",eReadWrite,},
	{0x578d, 0x03,"",eReadWrite,},
	{0x578e, 0x08,"",eReadWrite,},
	{0x578f, 0x0c,"",eReadWrite,},
	{0x5790, 0x08,"",eReadWrite,},
	{0x5791, 0x06,"",eReadWrite,},
	{0x5792, 0x00,"",eReadWrite,},
	{0x5793, 0x52,"",eReadWrite,},
	{0x5794, 0xa3,"",eReadWrite,},
	//fps fine adjustment
	{0x380e, 0x07,"",eReadWrite,},
	{0x380f, 0xf6,"",eReadWrite,},//fd
	// real gain [2]
	{0x3503, 0x00,"",eReadWrite,},
	//ULPM output low
	{0x3002, 0x61,"",eReadWrite,}, //[6]ULPM output enable
	{0x3010, 0x40,"",eReadWrite,}, //[6]enable ULPM as GPIO controlled by register
	{0x300D, 0x00,"",eReadWrite,}, //[6]ULPM output low (if 1=> high)
	//MWB bias manual
	{0x5045, 0x05,"",eReadWrite,},// [2] enable MWB manual bias
	{0x5048, 0x10,"",eReadWrite,},// MWB manual bias// need to be the same with 0x4003 BLC target.
	//VFPN improvement
	{0x3610, 0xa8,"",eReadWrite,},
	{0x3733, 0x10,"",eReadWrite,},
	{0x3734, 0x40,"",eReadWrite,},
	{0x0000, 0x05, "0x0100", eDelay}, //delay 5m,

	{0x0000 ,0x00,"eTableEnd",eTableEnd}
#endif
};

const IsiRegDescription_t OV5670_g_twolane_resolution_1280_960[] =
{
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};

const IsiRegDescription_t OV5670_g_twolane_resolution_2592_1944[] =
{
	//{0x0100, 0x01,"0x0100",eReadWrite}, 
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};

//hkw;
const IsiRegDescription_t OV5670_g_1280x960P30_twolane_fpschg[] =
{
	//{0x380e, 0x03,"0x0100",eReadWrite},
	//{0x380f, 0xe0,"0x0100",eReadWrite},
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};
const IsiRegDescription_t OV5670_g_1280x960P25_twolane_fpschg[] =
{
	//{0x380e, 0x04,"0x0100",eReadWrite},
	//{0x380f, 0xa6,"0x0100",eReadWrite},
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};
const IsiRegDescription_t OV5670_g_1280x960P20_twolane_fpschg[] =
{
	//{0x380e, 0x05,"0x0100",eReadWrite},
	//{0x380f, 0xd0,"0x0100",eReadWrite},
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};

const IsiRegDescription_t OV5670_g_1280x960P15_twolane_fpschg[] =
{
	//{0x380e, 0x07,"0x0100",eReadWrite},
	//{0x380f, 0xc0,"0x0100",eReadWrite},
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};
const IsiRegDescription_t OV5670_g_1280x960P10_twolane_fpschg[] =
{
	//{0x380e, 0x0b,"0x0100",eReadWrite},
	//{0x380f, 0xa0,"0x0100",eReadWrite},
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};


const IsiRegDescription_t OV5670_g_2592x1944P15_twolane_fpschg[] =
{
	{0x380e, 0x0f,"0x0100",eReadWrite},
	{0x380f, 0xec,"0x0100",eReadWrite},
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};
const IsiRegDescription_t OV5670_g_2592x1944P7_twolane_fpschg[] =
{
	{0x380e, 0x1f,"0x0100",eReadWrite},
	{0x380f, 0xd8,"0x0100",eReadWrite},
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};


//one lane
const IsiRegDescription_t OV5670_g_aRegDescription_onelane[] =
{
	   //OV support series
	{0x0103, 0x01,"",eReadWrite,},
	//{0x0000, 0x05, "0x0100", eDelay}, //delay 5m,
	{0x0100, 0x00,"",eReadWrite,},
	{0x0300, 0x04,"",eReadWrite,},
	{0x0301, 0x00,"",eReadWrite,},
	{0x0302, 0x69,"",eReadWrite,}, ////78// MIPI bit rate 960Mbps/lane -> 840Mbps/lane
	{0x0303, 0x00,"",eReadWrite,},
	{0x0304, 0x03,"",eReadWrite,},
	{0x0305, 0x01,"",eReadWrite,},
	{0x0306, 0x01,"",eReadWrite,},
	{0x030a, 0x00,"",eReadWrite,},
	{0x030b, 0x00,"",eReadWrite,},
	{0x030c, 0x00,"",eReadWrite,},
	{0x030d, 0x1e,"",eReadWrite,},
	{0x030e, 0x00,"",eReadWrite,},
	{0x030f, 0x06,"",eReadWrite,},
	{0x0312, 0x01,"",eReadWrite,},
	{0x3000, 0x00,"",eReadWrite,},
	{0x3002, 0x21,"",eReadWrite,},
	{0x3005, 0xf0,"",eReadWrite,},
	{0x3007, 0x00,"",eReadWrite,},
	{0x3015, 0x0f,"",eReadWrite,},
	{0x3018, 0x32,"",eReadWrite,},
	{0x301a, 0xf0,"",eReadWrite,},
	{0x301b, 0xf0,"",eReadWrite,},
	{0x301c, 0xf0,"",eReadWrite,},
	{0x301d, 0xf0,"",eReadWrite,},
	{0x301e, 0xf0,"",eReadWrite,},
	{0x3030, 0x00,"",eReadWrite,},
	{0x3031, 0x0a,"",eReadWrite,},
	{0x303c, 0xff,"",eReadWrite,},
	{0x303e, 0xff,"",eReadWrite,},
	{0x3040, 0xf0,"",eReadWrite,},
	{0x3041, 0x00,"",eReadWrite,},
	{0x3042, 0xf0,"",eReadWrite,},
	{0x3106, 0x11,"",eReadWrite,},
	{0x3500, 0x00,"",eReadWrite,},
	{0x3501, 0x7b,"",eReadWrite,},
	{0x3502, 0x00,"",eReadWrite,},
	{0x3503, 0x04,"",eReadWrite,},
	{0x3504, 0x03,"",eReadWrite,},
	{0x3505, 0x83,"",eReadWrite,},
	{0x3508, 0x04,"",eReadWrite,},
	{0x3509, 0x00,"",eReadWrite,},
	{0x350e, 0x04,"",eReadWrite,},
	{0x350f, 0x00,"",eReadWrite,},
	{0x3510, 0x00,"",eReadWrite,},
	{0x3511, 0x02,"",eReadWrite,},
	{0x3512, 0x00,"",eReadWrite,},
	{0x3601, 0xc8,"",eReadWrite,},
	{0x3610, 0x88,"",eReadWrite,},
	{0x3612, 0x48,"",eReadWrite,},
	{0x3614, 0x5b,"",eReadWrite,},
	{0x3615, 0x96,"",eReadWrite,},
	{0x3621, 0xd0,"",eReadWrite,},
	{0x3622, 0x00,"",eReadWrite,},
	{0x3623, 0x00,"",eReadWrite,},
	{0x3633, 0x13,"",eReadWrite,},
	{0x3634, 0x13,"",eReadWrite,},
	{0x3635, 0x13,"",eReadWrite,},
	{0x3636, 0x13,"",eReadWrite,},
	{0x3645, 0x13,"",eReadWrite,},
	{0x3646, 0x82,"",eReadWrite,},
	{0x3650, 0x00,"",eReadWrite,},
	{0x3652, 0xff,"",eReadWrite,},
	{0x3655, 0x20,"",eReadWrite,},
	{0x3656, 0xff,"",eReadWrite,},
	{0x365a, 0xff,"",eReadWrite,},
	{0x365e, 0xff,"",eReadWrite,},
	{0x3668, 0x00,"",eReadWrite,},
	{0x366a, 0x07,"",eReadWrite,},
	{0x366e, 0x10,"",eReadWrite,},
	{0x366d, 0x00,"",eReadWrite,},
	{0x366f, 0x80,"",eReadWrite,},
	{0x3700, 0x28,"",eReadWrite,},
	{0x3701, 0x10,"",eReadWrite,},
	{0x3702, 0x3a,"",eReadWrite,},
	{0x3703, 0x19,"",eReadWrite,},
	{0x3704, 0x10,"",eReadWrite,},
	{0x3705, 0x00,"",eReadWrite,},
	{0x3706, 0x66,"",eReadWrite,},
	{0x3707, 0x08,"",eReadWrite,},
	{0x3708, 0x34,"",eReadWrite,},
	{0x3709, 0x40,"",eReadWrite,},
	{0x370a, 0x01,"",eReadWrite,},
	{0x370b, 0x1b,"",eReadWrite,},
	{0x3714, 0x24,"",eReadWrite,},
	{0x371a, 0x3e,"",eReadWrite,},
	{0x3733, 0x00,"",eReadWrite,},
	{0x3734, 0x00,"",eReadWrite,},
	{0x373a, 0x05,"",eReadWrite,},
	{0x373b, 0x06,"",eReadWrite,},
	{0x373c, 0x0a,"",eReadWrite,},
	{0x373f, 0xa0,"",eReadWrite,},
	{0x3755, 0x00,"",eReadWrite,},
	{0x3758, 0x00,"",eReadWrite,},
	{0x375b, 0x0e,"",eReadWrite,},
	{0x3766, 0x5f,"",eReadWrite,},
	{0x3768, 0x00,"",eReadWrite,},
	{0x3769, 0x22,"",eReadWrite,},
	{0x3773, 0x08,"",eReadWrite,},
	{0x3774, 0x1f,"",eReadWrite,},
	{0x3776, 0x06,"",eReadWrite,},
	{0x37a0, 0x88,"",eReadWrite,},
	{0x37a1, 0x5c,"",eReadWrite,},
	{0x37a7, 0x88,"",eReadWrite,},
	{0x37a8, 0x70,"",eReadWrite,},
	{0x37aa, 0x88,"",eReadWrite,},
	{0x37ab, 0x48,"",eReadWrite,},
	{0x37b3, 0x66,"",eReadWrite,},
	{0x37c2, 0x04,"",eReadWrite,},
	{0x37c5, 0x00,"",eReadWrite,},
	{0x37c8, 0x00,"",eReadWrite,},
	{0x3800, 0x00,"",eReadWrite,},
	{0x3801, 0x0c,"",eReadWrite,},
	{0x3802, 0x00,"",eReadWrite,},
	{0x3803, 0x04,"",eReadWrite,},
	{0x3804, 0x0a,"",eReadWrite,},
	{0x3805, 0x33,"",eReadWrite,},
	{0x3806, 0x07,"",eReadWrite,},
	{0x3807, 0xa3,"",eReadWrite,},
	{0x3808, 0x0a,"",eReadWrite,},
	{0x3809, 0x20,"",eReadWrite,},
	{0x380a, 0x07,"",eReadWrite,},
	{0x380b, 0x98,"",eReadWrite,},
	{0x380c, 0x06,"",eReadWrite,},
	{0x380d, 0x90,"",eReadWrite,},//8c
	{0x380e, 0x07,"",eReadWrite,},
	{0x380f, 0xb8,"",eReadWrite,},
	{0x3811, 0x04,"",eReadWrite,},
	{0x3813, 0x02,"",eReadWrite,},
	{0x3814, 0x01,"",eReadWrite,},
	{0x3815, 0x01,"",eReadWrite,},
	{0x3816, 0x00,"",eReadWrite,},
	{0x3817, 0x00,"",eReadWrite,},
	{0x3818, 0x00,"",eReadWrite,},
	{0x3819, 0x00,"",eReadWrite,},
	{0x3820, 0x80,"",eReadWrite,},
	{0x3821, 0x46,"",eReadWrite,},
	{0x3822, 0x48,"",eReadWrite,},
	{0x3826, 0x00,"",eReadWrite,},
	{0x3827, 0x08,"",eReadWrite,},
	{0x382a, 0x01,"",eReadWrite,},
	{0x382b, 0x01,"",eReadWrite,},
	{0x3830, 0x08,"",eReadWrite,},
	{0x3836, 0x02,"",eReadWrite,},
	{0x3837, 0x00,"",eReadWrite,},
	{0x3838, 0x10,"",eReadWrite,},
	{0x3841, 0xff,"",eReadWrite,},
	{0x3846, 0x48,"",eReadWrite,},
	{0x3861, 0x00,"",eReadWrite,},
	{0x3862, 0x04,"",eReadWrite,},
	{0x3863, 0x06,"",eReadWrite,},
	{0x3a11, 0x01,"",eReadWrite,},
	{0x3a12, 0x78,"",eReadWrite,},
	{0x3b00, 0x00,"",eReadWrite,},
	{0x3b02, 0x00,"",eReadWrite,},
	{0x3b03, 0x00,"",eReadWrite,},
	{0x3b04, 0x00,"",eReadWrite,},
	{0x3b05, 0x00,"",eReadWrite,},
	{0x3c00, 0x89,"",eReadWrite,},
	{0x3c01, 0xab,"",eReadWrite,},
	{0x3c02, 0x01,"",eReadWrite,},
	{0x3c03, 0x00,"",eReadWrite,},
	{0x3c04, 0x00,"",eReadWrite,},
	{0x3c05, 0x03,"",eReadWrite,},
	{0x3c06, 0x00,"",eReadWrite,},
	{0x3c07, 0x05,"",eReadWrite,},
	{0x3c0c, 0x00,"",eReadWrite,},
	{0x3c0d, 0x00,"",eReadWrite,},
	{0x3c0e, 0x00,"",eReadWrite,},
	{0x3c0f, 0x00,"",eReadWrite,},
	{0x3c40, 0x00,"",eReadWrite,},
	{0x3c41, 0xa3,"",eReadWrite,},
	{0x3c43, 0x7d,"",eReadWrite,},
	{0x3c45, 0xd7,"",eReadWrite,},
	{0x3c47, 0xfc,"",eReadWrite,},
	{0x3c50, 0x05,"",eReadWrite,},
	{0x3c52, 0xaa,"",eReadWrite,},
	{0x3c54, 0x71,"",eReadWrite,},
	{0x3c56, 0x80,"",eReadWrite,},
	{0x3d85, 0x17,"",eReadWrite,},
	{0x3f03, 0x00,"",eReadWrite,},
	{0x3f0a, 0x00,"",eReadWrite,},
	{0x3f0b, 0x00,"",eReadWrite,},
	{0x4001, 0x60,"",eReadWrite,},
	{0x4009, 0x0d,"",eReadWrite,},
	{0x4020, 0x00,"",eReadWrite,},
	{0x4021, 0x00,"",eReadWrite,},
	{0x4022, 0x00,"",eReadWrite,},
	{0x4023, 0x00,"",eReadWrite,},
	{0x4024, 0x00,"",eReadWrite,},
	{0x4025, 0x00,"",eReadWrite,},
	{0x4026, 0x00,"",eReadWrite,},
	{0x4027, 0x00,"",eReadWrite,},
	{0x4028, 0x00,"",eReadWrite,},
	{0x4029, 0x00,"",eReadWrite,},
	{0x402a, 0x00,"",eReadWrite,},
	{0x402b, 0x00,"",eReadWrite,},
	{0x402c, 0x00,"",eReadWrite,},
	{0x402d, 0x00,"",eReadWrite,},
	{0x402e, 0x00,"",eReadWrite,},
	{0x402f, 0x00,"",eReadWrite,},
	{0x4040, 0x00,"",eReadWrite,},
	{0x4041, 0x03,"",eReadWrite,},
	{0x4042, 0x00,"",eReadWrite,},
	{0x4043, 0x7A,"",eReadWrite,}, // 1/1.05 x (0x80)
	{0x4044, 0x00,"",eReadWrite,},
	{0x4045, 0x7A,"",eReadWrite,},
	{0x4046, 0x00,"",eReadWrite,},
	{0x4047, 0x7A,"",eReadWrite,},
	{0x4048, 0x00,"",eReadWrite,},
	{0x4049, 0x7A,"",eReadWrite,},
	{0x4303, 0x00,"",eReadWrite,},
	{0x4307, 0x30,"",eReadWrite,},
	{0x4500, 0x58,"",eReadWrite,},
	{0x4501, 0x04,"",eReadWrite,},
	{0x4502, 0x40,"",eReadWrite,},
	{0x4503, 0x10,"",eReadWrite,},
	{0x4508, 0xaa,"",eReadWrite,},
	{0x4509, 0xaa,"",eReadWrite,},
	{0x450a, 0x00,"",eReadWrite,},
	{0x450b, 0x00,"",eReadWrite,},
	{0x4600, 0x01,"",eReadWrite,},
	{0x4601, 0x03,"",eReadWrite,},
	{0x4700, 0xa4,"",eReadWrite,},
	{0x4800, 0x4c,"",eReadWrite,},
	{0x4816, 0x53,"",eReadWrite,},
	{0x481f, 0x40,"",eReadWrite,},
	{0x4837, 0x13,"",eReadWrite,},//11// MIPI global timing
	{0x5000, 0x56,"",eReadWrite,},
	{0x5001, 0x01,"",eReadWrite,},
	{0x5002, 0x28,"",eReadWrite,},
	{0x5004, 0x0c,"",eReadWrite,},
	{0x5006, 0x0c,"",eReadWrite,},
	{0x5007, 0xe0,"",eReadWrite,},
	{0x5008, 0x01,"",eReadWrite,},
	{0x5009, 0xb0,"",eReadWrite,},
	{0x5901, 0x00,"",eReadWrite,},
	{0x5a01, 0x00,"",eReadWrite,},
	{0x5a03, 0x00,"",eReadWrite,},
	{0x5a04, 0x0c,"",eReadWrite,},
	{0x5a05, 0xe0,"",eReadWrite,},
	{0x5a06, 0x09,"",eReadWrite,},
	{0x5a07, 0xb0,"",eReadWrite,},
	{0x5a08, 0x06,"",eReadWrite,},
	{0x5e00, 0x00,"",eReadWrite,},
	{0x3734, 0x40,"",eReadWrite,},
	{0x5b00, 0x01,"",eReadWrite,},
	{0x5b01, 0x10,"",eReadWrite,},
	{0x5b02, 0x01,"",eReadWrite,},
	{0x5b03, 0xdb,"",eReadWrite,},
	{0x3d8c, 0x71,"",eReadWrite,},
	{0x3d8d, 0xea,"",eReadWrite,},
	{0x4017, 0x08,"",eReadWrite,},
	{0x3618, 0x2a,"",eReadWrite,},
	
	//Ping
	//Strong DPC1.53
	{0x5780, 0x3e,"",eReadWrite,},
	{0x5781, 0x0f,"",eReadWrite,},
	{0x5782, 0x44,"",eReadWrite,},
	{0x5783, 0x02,"",eReadWrite,},
	{0x5784, 0x01,"",eReadWrite,},
	{0x5785, 0x01,"",eReadWrite,},
	{0x5786, 0x00,"",eReadWrite,},
	{0x5787, 0x04,"",eReadWrite,},
	{0x5788, 0x02,"",eReadWrite,},
	{0x5789, 0x0f,"",eReadWrite,},
	{0x578a, 0xfd,"",eReadWrite,},
	{0x578b, 0xf5,"",eReadWrite,},
	{0x578c, 0xf5,"",eReadWrite,},
	{0x578d, 0x03,"",eReadWrite,},
	{0x578e, 0x08,"",eReadWrite,},
	{0x578f, 0x0c,"",eReadWrite,},
	{0x5790, 0x08,"",eReadWrite,},
	{0x5791, 0x06,"",eReadWrite,},
	{0x5792, 0x00,"",eReadWrite,},
	{0x5793, 0x52,"",eReadWrite,},
	{0x5794, 0xa3,"",eReadWrite,},
	//fps fine adjustment
	{0x380e, 0x07,"",eReadWrite,},
	{0x380f, 0xf6,"",eReadWrite,},//fd
	// real gain [2]
	{0x3503, 0x00,"",eReadWrite,},
	//ULPM output low
	{0x3002, 0x61,"",eReadWrite,}, //[6]ULPM output enable
	{0x3010, 0x40,"",eReadWrite,}, //[6]enable ULPM as GPIO controlled by register
	{0x300D, 0x00,"",eReadWrite,}, //[6]ULPM output low (if 1=> high)
	//MWB bias manual
	{0x5045, 0x05,"",eReadWrite,},// [2] enable MWB manual bias
	{0x5048, 0x10,"",eReadWrite,},// MWB manual bias// need to be the same with 0x4003 BLC target.
	//VFPN improvement
	{0x3610, 0xa8,"",eReadWrite,},
	{0x3733, 0x10,"",eReadWrite,},
	{0x3734, 0x40,"",eReadWrite,},
	//{0x0100, 0x01,"",eReadWrite,},

	//@@ 1 15 MIPI_1_LANE_840Mbps_15FPS
	//RUN FORMAT_1_2592X1944_FULL_30FPS_MIPI_2_LANE_840Mbps
	{0x0100, 0x00, "", eReadWrite,}, //
	{0x3018, 0x12, "", eReadWrite,}, //MIPI 1 lane
	{0x380c, 0x0d, "", eReadWrite,},
	{0x380d, 0x20, "", eReadWrite,}, //18
	//{0x0100, 0x01, "", eReadWrite,}, //
//	{0x0100, 0x01,"0x0100",eReadWrite},
	{0x0000, 0x05, "0x0100", eDelay}, //delay 5m,

	/* MIPI CLK Lane Mode test*/
	//{0x4800, 0x6c,"",eReadWrite,},
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};

const IsiRegDescription_t OV5670_g_onelane_resolution_1280_960[] =
{
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};

const IsiRegDescription_t OV5670_g_onelane_resolution_2592_1944[] =
{
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};


const IsiRegDescription_t OV5670_g_1280x960P30_onelane_fpschg[] =
{
	//{0x380e, 0x03,"0x0100",eReadWrite},
	//{0x380f, 0xe0,"0x0100",eReadWrite},
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};
const IsiRegDescription_t OV5670_g_1280x960P25_onelane_fpschg[] =
{
	//{0x380e, 0x04,"0x0100",eReadWrite},
	//{0x380f, 0xa6,"0x0100",eReadWrite},
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};
const IsiRegDescription_t OV5670_g_1280x960P20_onelane_fpschg[] =
{
	//{0x380e, 0x05,"0x0100",eReadWrite},
	//{0x380f, 0xd0,"0x0100",eReadWrite},
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};

const IsiRegDescription_t OV5670_g_1280x960P15_onelane_fpschg[] =
{
	//{0x380e, 0x07,"0x0100",eReadWrite},
	//{0x380f, 0xc0,"0x0100",eReadWrite},
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};
const IsiRegDescription_t OV5670_g_1280x960P10_onelane_fpschg[] =
{
	//{0x380e, 0x0b,"0x0100",eReadWrite},
	//{0x380f, 0xa0,"0x0100",eReadWrite},
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};


const IsiRegDescription_t OV5670_g_2592x1944P15_onelane_fpschg[] =
{
	{0x380e, 0x07,"0x0100",eReadWrite},
	{0x380f, 0xf6,"0x0100",eReadWrite},
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};
const IsiRegDescription_t OV5670_g_2592x1944P7_onelane_fpschg[] =
{
	{0x380e, 0x0f,"0x0100",eReadWrite},
	{0x380f, 0xec,"0x0100",eReadWrite},
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};

