//HM2140_tables.c
/*****************************************************************************/
/*!
 *  \file        HM2140_tables.c \n
 *  \version     1.0 \n
 *  \author      Zefa.chen \n
 *  \brief       Image-sensor-specific tables and other
 *               constant values/structures for HM2140. \n
 *
 *  \revision    $Revision: 803 $ \n
 *               $Author: $ \n
 *               $Date: 2010-02-26 16:35:22 +0100 (Fr, 26 Feb 2010) $ \n
 *               $Id: HM2140_tables.c 803 2010-02-26 15:35:22Z  $ \n
 */
/*  This is an unpublished work, the copyright in which vests in Silicon Image
 *  GmbH. The information contained herein is the property of Silicon Image GmbH
 *  and is supplied without liability for errors or omissions. No part may be
 *  reproduced or used expect as authorized by contract or other written
 *  permission. Copyright(c) Silicon Image GmbH, 2009, all rights reserved.
 */
/*****************************************************************************/
/*
#include "stdinc.h"

#if( HM2140_DRIVER_USAGE == USE_CAM_DRV_EN )
*/


#include <ebase/types.h>
#include <ebase/trace.h>
#include <ebase/builtins.h>

#include <common/return_codes.h>

#include "isi.h"
#include "isi_iss.h"
#include "isi_priv.h"
#include "HM2140_MIPI_priv.h"


/*****************************************************************************
 * DEFINES
 *****************************************************************************/


/*****************************************************************************
 * GLOBALS
 *****************************************************************************/

// Image sensor register settings default values taken from data sheet OV13850_DS_1.1_SiliconImage.pdf.
// The settings may be altered by the code in IsiSetupSensor.

//2 lane
const IsiRegDescription_t Sensor_g_aRegDescription[] =
{
	
    //{0x0103,0x00, "eReadWrite",eReadWrite}, 

    {0x0100,0x00, "eReadWrite",eReadWrite}, 

    {0x5227,0x6F, "eReadWrite",eReadWrite}, 

    {0x030B,0x01, "eReadWrite",eReadWrite}, 

    {0x0307,0x00, "eReadWrite",eReadWrite}, 

    {0x0309,0x00, "eReadWrite",eReadWrite}, 

    {0x030A,0x0A, "eReadWrite",eReadWrite}, 

    {0x030D,0x02, "eReadWrite",eReadWrite}, 

    {0x030F,0x10, "eReadWrite",eReadWrite}, 

    {0x5235,0x24, "eReadWrite",eReadWrite}, 

    {0x5236,0x92, "eReadWrite",eReadWrite}, 

    {0x5237,0x23, "eReadWrite",eReadWrite}, 

    {0x5238,0xDC, "eReadWrite",eReadWrite}, 

    {0x5239,0x01, "eReadWrite",eReadWrite}, 

    {0x0100,0x02, "eReadWrite",eReadWrite}, 

    {0x4001,0x00, "eReadWrite",eReadWrite}, 

    {0x4002,0x2B, "eReadWrite",eReadWrite}, 

    {0x0101, 0x00, "eReadWrite",eReadWrite}, 

    {0x4026, 0x3B, "eReadWrite",eReadWrite}, 

    {0x0202, 0x02, "eReadWrite",eReadWrite}, 

    {0x0203, 0xEC, "eReadWrite",eReadWrite}, //ce

    {0x0340, 0x04, "eReadWrite",eReadWrite}, 

    {0x0341, 0x56, "eReadWrite",eReadWrite}, 

    {0x0342, 0x08, "eReadWrite",eReadWrite}, 

    {0x0343, 0xFC, "eReadWrite",eReadWrite}, 

    {0x0350, 0x73, "eReadWrite",eReadWrite}, 

    {0x5015, 0xB3, "eReadWrite",eReadWrite}, 

    {0x50DD, 0x00, "eReadWrite",eReadWrite}, //SMIA GAIN CODE

    {0x50CB, 0xA3, "eReadWrite",eReadWrite}, 

    {0x5004, 0x40, "eReadWrite",eReadWrite}, //07

    {0x5005, 0x28, "eReadWrite",eReadWrite}, 

    {0x504D, 0x7F, "eReadWrite",eReadWrite}, 

    {0x504E, 0x00, "eReadWrite",eReadWrite}, 

    {0x5040, 0x07, "eReadWrite",eReadWrite}, 

    {0x5011, 0x00,"eReadWrite",eReadWrite}, 

    //                      

    {0x501D, 0x4C, "eReadWrite",eReadWrite}, 

    {0x5011, 0x0B, "eReadWrite",eReadWrite}, 

    {0x5012, 0x01, "eReadWrite",eReadWrite}, 

    {0x5013, 0x03, "eReadWrite",eReadWrite}, 

    {0x4131, 0x00, "eReadWrite",eReadWrite}, 

    {0x5282, 0xFF, "eReadWrite",eReadWrite}, 

    {0x5283, 0x07, "eReadWrite",eReadWrite}, 

    {0x5010, 0x20, "eReadWrite",eReadWrite}, 

    {0x4132, 0x20, "eReadWrite",eReadWrite}, 

    {0x50D5, 0xE0, "eReadWrite",eReadWrite}, 

    {0x50D7, 0x12, "eReadWrite",eReadWrite}, 

    {0x50BB, 0x14, "eReadWrite",eReadWrite}, 

    {0x50B7, 0x00, "eReadWrite",eReadWrite}, 

    {0x50B8, 0x35, "eReadWrite",eReadWrite}, 

    {0x50B9, 0x10, "eReadWrite",eReadWrite}, 

    {0x50BA, 0xF0, "eReadWrite",eReadWrite}, 

    {0x50B3, 0x24, "eReadWrite",eReadWrite}, 

    {0x50B4, 0x00, "eReadWrite",eReadWrite}, 

    {0x50FA, 0x02, "eReadWrite",eReadWrite}, 

    {0x509B, 0x01, "eReadWrite",eReadWrite}, 

    {0x50AA, 0xFF, "eReadWrite",eReadWrite}, 

    {0x50AB, 0x27, "eReadWrite",eReadWrite}, 

    {0x509C, 0x00, "eReadWrite",eReadWrite}, 

    {0x50AD, 0x0C, "eReadWrite",eReadWrite},  //HiMOS_20160713

    {0x5096, 0x00, "eReadWrite",eReadWrite},  //HiMOS_20160713

    {0x50A1, 0x12, "eReadWrite",eReadWrite}, 

    {0x50AF, 0x31, "eReadWrite",eReadWrite},  //HiMOS_20160713

    {0x50A0, 0x11, "eReadWrite",eReadWrite}, 

    {0x50A2, 0x22, "eReadWrite",eReadWrite}, 

    {0x509D, 0x20, "eReadWrite",eReadWrite}, 

    {0x50AC, 0x55, "eReadWrite",eReadWrite}, 

    {0x50AE, 0x26, "eReadWrite",eReadWrite}, 

    {0x509E, 0x03, "eReadWrite",eReadWrite}, 

    {0x509F, 0x01, "eReadWrite",eReadWrite}, 

    {0x5097, 0x12, "eReadWrite",eReadWrite}, 

    {0x5099, 0x00, "eReadWrite",eReadWrite}, //HiMOS_20160720

    {0x50B5, 0x00, "eReadWrite",eReadWrite}, 

    {0x50B6, 0x10, "eReadWrite",eReadWrite},	

    {0x5094, 0x08, "eReadWrite",eReadWrite},	

    {0x5200, 0x43, "eReadWrite",eReadWrite},	

    { 0x5201, 0xC0, "eReadWrite",eReadWrite},	

    {0x5202, 0x00, "eReadWrite",eReadWrite},	

    {0x5203, 0x00, "eReadWrite",eReadWrite},	

    {0x5204, 0x00, "eReadWrite",eReadWrite},	

    {0x5205, 0x05, "eReadWrite",eReadWrite},	

    {0x5206, 0xA1, "eReadWrite",eReadWrite},	

    {0x5207, 0x01, "eReadWrite",eReadWrite},	

    {0x5208, 0x05, "eReadWrite",eReadWrite},	

    {0x5209, 0x0C, "eReadWrite",eReadWrite},	

    {0x520A, 0x00, "eReadWrite",eReadWrite},  //HiMOS_20160713

    {0x520B, 0x45, "eReadWrite",eReadWrite},	

    {0x520C, 0x15, "eReadWrite",eReadWrite},	

    {0x520D, 0x40, "eReadWrite",eReadWrite},	

    {0x520E, 0x50, "eReadWrite",eReadWrite},	

    { 0x520F, 0x10, "eReadWrite",eReadWrite},	

    {0x5214, 0x40, "eReadWrite",eReadWrite},	

    {0x5215, 0x14, "eReadWrite",eReadWrite},	

    {0x5216, 0x00, "eReadWrite",eReadWrite},  //HiMOS_20160919

    {0x5217, 0x02, "eReadWrite",eReadWrite},	

    {0x5218, 0x07, "eReadWrite",eReadWrite},	

    {0x521C, 0x00, "eReadWrite",eReadWrite},	

    {0x521E, 0x00, "eReadWrite",eReadWrite},	

    {0x522A, 0x3F, "eReadWrite",eReadWrite},	

    {0x522C, 0x00, "eReadWrite",eReadWrite},	

    {0x5230, 0x00, "eReadWrite",eReadWrite},	

    {0x5232, 0x05, "eReadWrite",eReadWrite},	

    {0x523A, 0x20, "eReadWrite",eReadWrite},	

    {0x523B, 0x34, "eReadWrite",eReadWrite},	

    {0x523C, 0x03, "eReadWrite",eReadWrite},	

    {0x523D, 0x40, "eReadWrite",eReadWrite},	

    {0x523E, 0x00, "eReadWrite",eReadWrite},	

    {0x523F, 0x70, "eReadWrite",eReadWrite},	

    {0x50E8, 0x14, "eReadWrite",eReadWrite},	

    {0x50E9, 0x00, "eReadWrite",eReadWrite},	

    {0x50EB, 0x0F, "eReadWrite",eReadWrite},	

    {0x4B11, 0x0F, "eReadWrite",eReadWrite},	

    {0x4B12, 0x0F, "eReadWrite",eReadWrite},	

    {0x4B31, 0x04, "eReadWrite",eReadWrite},  //HiMOS_20160919

    { 0x4B3B, 0x02, "eReadWrite",eReadWrite},	

    {0x4B44, 0x80, "eReadWrite",eReadWrite},	

    {0x4B45, 0x00, "eReadWrite",eReadWrite},	

    {0x4B47, 0x00, "eReadWrite",eReadWrite},	

    {0x4B4E, 0x30, "eReadWrite",eReadWrite},	

    {0x4020, 0x20, "eReadWrite",eReadWrite},	

    {0x5100, 0x1B, "eReadWrite",eReadWrite},	

    {0x5101, 0x2B, "eReadWrite",eReadWrite},	

    {0x5102, 0x3B, "eReadWrite",eReadWrite},	

    {0x5103, 0x4B, "eReadWrite",eReadWrite},	

    {0x5104, 0x5F, "eReadWrite",eReadWrite},	

    {0x5105, 0x6F, "eReadWrite",eReadWrite},	

    {0x5106, 0x7F, "eReadWrite",eReadWrite},	

    {0x5108, 0x00, "eReadWrite",eReadWrite},	

    {0x5109, 0x00, "eReadWrite",eReadWrite},	

    {0x510A, 0x00, "eReadWrite",eReadWrite},	

    {0x510B, 0x00, "eReadWrite",eReadWrite},	

    {0x510C, 0x00, "eReadWrite",eReadWrite},	

    {0x510D, 0x00, "eReadWrite",eReadWrite},	

    {0x510E, 0x00, "eReadWrite",eReadWrite},	

    {0x5110, 0x0E, "eReadWrite",eReadWrite},	

    {0x5111, 0x0E, "eReadWrite",eReadWrite},	

    {0x5112, 0x0E, "eReadWrite",eReadWrite},	

    {0x5113, 0x0E, "eReadWrite",eReadWrite},	

    {0x5114, 0x0E, "eReadWrite",eReadWrite},	

    {0x5115, 0x0E, "eReadWrite",eReadWrite},	

    {0x5116, 0x0E, "eReadWrite",eReadWrite},	

    {0x5118, 0x09, "eReadWrite",eReadWrite},	

    {0x5119, 0x09, "eReadWrite",eReadWrite},	

    {0x511A, 0x09, "eReadWrite",eReadWrite},	

    {0x511B, 0x09, "eReadWrite",eReadWrite},  //

    {0x511C, 0x09, "eReadWrite",eReadWrite},  //

    {0x511D, 0x09, "eReadWrite",eReadWrite},  //

    {0x511E, 0x09, "eReadWrite",eReadWrite},  //

    {0x5120, 0xEA, "eReadWrite",eReadWrite},  //

    {0x5121, 0x6A, "eReadWrite",eReadWrite},	

    {0x5122, 0x6A, "eReadWrite",eReadWrite},  //

    { 0x5123, 0x6A, "eReadWrite",eReadWrite},	

    {0x5124, 0x6A, "eReadWrite",eReadWrite},	

    {0x5125, 0x6A, "eReadWrite",eReadWrite},	

    {0x5126, 0x6A, "eReadWrite",eReadWrite},	

    {0x5140, 0x0B, "eReadWrite",eReadWrite},	

    {0x5141, 0x1B, "eReadWrite",eReadWrite},	

    {0x5142, 0x2B, "eReadWrite",eReadWrite},	

    {0x5143, 0x3B, "eReadWrite",eReadWrite},	

    {0x5144, 0x4B, "eReadWrite",eReadWrite},	

    {0x5145, 0x5B, "eReadWrite",eReadWrite},	

    {0x5146, 0x6B, "eReadWrite",eReadWrite},	

    {0x5148, 0x02, "eReadWrite",eReadWrite},	

    {0x5149, 0x02, "eReadWrite",eReadWrite},	

    {0x514A, 0x02, "eReadWrite",eReadWrite},	

    {0x514B, 0x02, "eReadWrite",eReadWrite},	

    {0x514C, 0x02, "eReadWrite",eReadWrite},	

    { 0x514D, 0x02, "eReadWrite",eReadWrite},	

    {0x514E, 0x02, "eReadWrite",eReadWrite},	

    {0x5150, 0x08, "eReadWrite",eReadWrite},	

    {0x5151, 0x08, "eReadWrite",eReadWrite}, 

    {0x5152, 0x08, "eReadWrite",eReadWrite}, 

    {0x5153, 0x08, "eReadWrite",eReadWrite}, 

    {0x5154, 0x08, "eReadWrite",eReadWrite}, 

    {0x5155, 0x08, "eReadWrite",eReadWrite}, 

    {0x5156, 0x08, "eReadWrite",eReadWrite}, 

    {0x5158, 0x02, "eReadWrite",eReadWrite}, 

    {0x5159, 0x02, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x515A, 0x02, "eReadWrite",eReadWrite},  //HiMOS_20160720

  	{0x515B, 0x02, "eReadWrite",eReadWrite},  //HiMOS_20160720 

    {0x515C, 0x02, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x515D, 0x02, "eReadWrite",eReadWrite}, 

    {0x515E, 0x02, "eReadWrite",eReadWrite}, 

    {0x5160, 0x66, "eReadWrite",eReadWrite}, 

    {0x5161, 0x66, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x5162, 0x66, "eReadWrite",eReadWrite},	

    {0x5163, 0x66, "eReadWrite",eReadWrite},	

    {0x5164, 0x66, "eReadWrite",eReadWrite},	

    {0x5165, 0x66, "eReadWrite",eReadWrite},	

    {0x5166, 0x66, "eReadWrite",eReadWrite},	

    {0x5180, 0x00, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x5189, 0x00, "eReadWrite",eReadWrite},	

    {0x5192, 0x00, "eReadWrite",eReadWrite},	

    {0x519B, 0x00, "eReadWrite",eReadWrite},	

    {0x51A4, 0x00, "eReadWrite",eReadWrite},	

    {0x51AD, 0x00, "eReadWrite",eReadWrite},	

    {0x51B6, 0x00, "eReadWrite",eReadWrite},	

    {0x51C0, 0x00, "eReadWrite",eReadWrite},	

    {0x5181, 0x00, "eReadWrite",eReadWrite},	

    {0x518A,0x00, "eReadWrite",eReadWrite},	

    {0x5193,0x00, "eReadWrite",eReadWrite},	

    {0x519C, 0x00, "eReadWrite",eReadWrite},	

    {0x51A5, 0x00, "eReadWrite",eReadWrite},	

    {0x51AE, 0x00, "eReadWrite",eReadWrite},	

    {0x51B7, 0x00, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x51C1, 0x00, "eReadWrite",eReadWrite},	

    {0x5182, 0x85, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x518B, 0x85, "eReadWrite",eReadWrite},	

    {0x5194, 0x85, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x519D, 0x85, "eReadWrite",eReadWrite},	

    {0x51A6, 0x85, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x51AF, 0x85, "eReadWrite",eReadWrite},	

    {0x51B8, 0x85, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x51C2, 0x85, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x5183, 0x52, "eReadWrite",eReadWrite},  //HiMOS_20160720 

    {0x518C, 0x52, "eReadWrite",eReadWrite},	 
    
    {0x5195, 0x52, "eReadWrite",eReadWrite}, 

    {0x519E, 0x52, "eReadWrite",eReadWrite}, 

    {0x51A7, 0x52, "eReadWrite",eReadWrite}, 

    {0x51B0, 0x52, "eReadWrite",eReadWrite},		 
    
    {0x51B9, 0x52, "eReadWrite",eReadWrite},	
    
    {0x51C3, 0x52, "eReadWrite",eReadWrite},	
    
    {0x5184, 0x00, "eReadWrite",eReadWrite},	
    
    {0x518D, 0x00, "eReadWrite",eReadWrite},	
    
    {0x5196, 0x08, "eReadWrite",eReadWrite},	
    
    {0x519F, 0x08, "eReadWrite",eReadWrite},	
    
    {0x51A8, 0x08, "eReadWrite",eReadWrite},	
    
    {0x51B1, 0x08, "eReadWrite",eReadWrite},	
    
    {0x51BA, 0x08, "eReadWrite",eReadWrite},	
    
    {0x51C4, 0x08, "eReadWrite",eReadWrite},	
    
    {0x5185, 0x73, "eReadWrite",eReadWrite},	
    
    {0x518E, 0x73, "eReadWrite",eReadWrite},	
    
    {0x5197, 0x73, "eReadWrite",eReadWrite},	
    
    {0x51A0, 0x73, "eReadWrite",eReadWrite},	
    
    {0x51A9, 0x73, "eReadWrite",eReadWrite},	
    
    {0x51B2, 0x73, "eReadWrite",eReadWrite},	
    
    {0x51BB, 0x73, "eReadWrite",eReadWrite},	
    
    {0x51C5, 0x73, "eReadWrite",eReadWrite},	
    
    {0x5186, 0x34, "eReadWrite",eReadWrite},	
    
    {0x518F, 0x34, "eReadWrite",eReadWrite},	
    
    { 0x5198, 0x34, "eReadWrite",eReadWrite},	
    
    {0x51A1, 0x34, "eReadWrite",eReadWrite},	
    
    {0x51AA, 0x34, "eReadWrite",eReadWrite},	
    
    {0x51B3, 0x3F, "eReadWrite",eReadWrite},	
    
    {0x51BC, 0x3F, "eReadWrite",eReadWrite},	
    
    {0x51C6, 0x3F, "eReadWrite",eReadWrite},	
    
    {0x5187, 0x40, "eReadWrite",eReadWrite},	
    
    {0x5190, 0x38, "eReadWrite",eReadWrite},	
    
    {0x5199, 0x20, "eReadWrite",eReadWrite},	
    
    {0x51A2, 0x08, "eReadWrite",eReadWrite},	
    
    {0x51AB, 0x04, "eReadWrite",eReadWrite},	
    
    {0x51B4, 0x04, "eReadWrite",eReadWrite},	
    
    {0x51BD, 0x02, "eReadWrite",eReadWrite},	
    
    {0x51C7, 0x01, "eReadWrite",eReadWrite},	
    
    {0x5188, 0x20, "eReadWrite",eReadWrite},	
    
    {0x5191, 0x40, "eReadWrite",eReadWrite},	
    
    {0x519A, 0x40, "eReadWrite",eReadWrite},	
    
    {0x51A3, 0x40, "eReadWrite",eReadWrite},	
    
    {0x51AC, 0x40, "eReadWrite",eReadWrite},	
    
    {0x51B5, 0x78, "eReadWrite",eReadWrite},	
    
    {0x51BE, 0x78, "eReadWrite",eReadWrite},	
    
    {0x51C8, 0x78, "eReadWrite",eReadWrite},	
    
    {0x51E1, 0x07, "eReadWrite",eReadWrite},	
    
    {0x51E3, 0x07, "eReadWrite",eReadWrite},	
    
    {0x51E5, 0x07, "eReadWrite",eReadWrite},	
    
    {0x51ED, 0x00, "eReadWrite",eReadWrite},	
    
    {0x51EE, 0x00, "eReadWrite",eReadWrite},	
    
    {0x4002, 0x2B, "eReadWrite",eReadWrite},	
    
    {0x3132, 0x00, "eReadWrite",eReadWrite},	
    
    {0x4024, 0x40, "eReadWrite",eReadWrite},	
    
    {0x5229, 0xFC, "eReadWrite",eReadWrite},	
    
    {0x4002, 0x2B, "eReadWrite",eReadWrite},	
    
    {0x3110, 0x03, "eReadWrite",eReadWrite},	
    
    {0x373D, 0x12, "eReadWrite",eReadWrite},	
    
    {0xBAA2, 0xC0, "eReadWrite",eReadWrite},	
    
    {0xBAA2, 0x40, "eReadWrite",eReadWrite},	
    
    {0xBA90, 0x01, "eReadWrite",eReadWrite},	
    
    {0xBA93, 0x02, "eReadWrite",eReadWrite},	
    
    {0x350D, 0x01, "eReadWrite",eReadWrite},	
    
    {0x3514, 0x00, "eReadWrite",eReadWrite},	
    
    {0x350C, 0x01, "eReadWrite",eReadWrite},	
    
    {0x3519, 0x00, "eReadWrite",eReadWrite},	
    
    {0x351A, 0x01, "eReadWrite",eReadWrite},	
    
    {0x351B, 0x1E, "eReadWrite",eReadWrite},	
    
    {0x351C, 0x90, "eReadWrite",eReadWrite},	
    
    {0x351E, 0x05, "eReadWrite",eReadWrite},	
    
    {0x351D, 0x05, "eReadWrite",eReadWrite},	
    
    {0x4B20, 0x9E, "eReadWrite",eReadWrite},	
    
    {0x4B18, 0x00, "eReadWrite",eReadWrite},	
    
    {0x4B3E, 0x00, "eReadWrite",eReadWrite},	
    
    {0x4B0E, 0x21, "eReadWrite",eReadWrite},	
    
    {0x4800, 0xAC, "eReadWrite",eReadWrite},	
    
    {0x0104, 0x01, "eReadWrite",eReadWrite},
    
    {0x0104, 0x00, "eReadWrite",eReadWrite},	
    
    {0x4801, 0xAE, "eReadWrite",eReadWrite},		

	  {0x0000 ,0x00, "eReadWrite",eTableEnd}
	  
};

//SMIA GAIN CODE
//zefa.chen@rock-chips.com
const sensor_again_table_t sensor_A_gain_table[]=
{
    {0x00, 10000 },
    {0x01, 10625 },
    {0x02, 11250 },
    {0x03, 11875 },
    {0x04, 12500 },
    {0x05, 13125 },
    {0x06, 13750 },
    {0x07, 14375 },
    {0x08, 15000 },
    {0x09, 15625 },
    {0x0A, 16250 },
    {0x0B, 16875 },
    {0x0C, 17500 },
    {0x0D, 18125 },
    {0x0E, 18750 },
    {0x0F, 19375 },
    {0x10, 20000 },
    {0x12, 21250 },
    {0x14, 22500 },
    {0x16, 23750 },
    {0x18, 25000 },
    {0x1A, 26250 },
    {0x1C, 27500 },
    {0x1E, 28750 },
    {0x20, 30000 },
    {0x22, 31250 },
    {0x24, 32500 },
    {0x26, 33750 },
    {0x28, 35000 },
    {0x2A, 36250 },
    {0x2C, 37500 },
    {0x2E, 38750 },
    {0x30, 40000 },
    {0x34, 42500 },
    {0x38, 45000 },
    {0x3C, 47500 },
    {0x40, 50000 },
    {0x44, 52500 },
    {0x48, 55000 },
    {0x4C, 57500 },
    {0x50, 60000 },
    {0x54, 62500 },
    {0x58, 65000 },
    {0x5C, 67500 },
    {0x60, 70000 },
    {0x64, 72500 },
    {0x68, 75000 },
    {0x6C, 77500 },
    {0x70, 80000 },
    {0x78, 85000 },
    {0x80, 90000 },
    {0x88, 95000 },
    {0x90, 100000},
    {0x98, 105000},
    {0xA0, 110000},
    {0xA8, 115000},
    {0xB0, 120000},
    {0xB8, 125000},
    {0xC0, 130000},
    {0xC8, 135000},
    {0xD0, 140000},
    {0xD8, 145000},
    {0xE0, 150000},
    {0xE8, 155000},
    //MAX GAIN = 15.5
    {0x40, 160000},
    {0x41, 170000},
    {0x42, 180000},
    {0x43, 190000},
    {0x44, 200000},
    {0x45, 210000},
    {0x46, 220000},
    {0x47, 230000},
    {0x48, 240000},
    {0x49, 250000},
    {0x4A, 260000},
    {0x4B, 270000},
    {0x4C, 280000},
    {0x4D, 290000},
    {0x4E, 300000},
    {0x4F, 310000},
    {0x50, 320000},
    {0x51, 340000},
    {0x52, 360000},
    {0x53, 380000},
    {0x54, 400000},
    {0x55, 420000},
    {0x56, 440000},
    {0x57, 460000},
    {0x58, 480000},
    {0x59, 500000},
    {0x5A, 520000},
    {0x5B, 540000},
    {0x5C, 560000},
    {0x5D, 580000},
    {0x5E, 600000},
    {0x5F, 620000},
    {0xFF, 0}
    
};

/*
const IsiRegDescription_t Sensor_g_svga[] =
{

};
*/

const IsiRegDescription_t Sensor_g_1920x1080[] =
{
    {0x0340,0x0E, "eReadWrite",eReadWrite}, 

    {0x0341,0x82, "eReadWrite",eReadWrite},  //HiMOS_20160713

    {0x0342,0x05, "eReadWrite",eReadWrite}, 

    {0x0343,0x00, "eReadWrite",eReadWrite}, 

    {0x034C,0x07, "eReadWrite",eReadWrite}, 

    {0x034D,0x80, "eReadWrite",eReadWrite}, 

    {0x034E,0x04, "eReadWrite",eReadWrite}, 

    {0x034F,0x38, "eReadWrite",eReadWrite},                      	

    {0x0000, 0x00,"eReadWrite",eTableEnd}
};

const IsiRegDescription_t Sensor_g_1920x1080_30fps[] =
{
	{0x0340, 0x04,"eReadWrite",eTableEnd},

	{0x0341, 0xD6,"eReadWrite",eTableEnd},	//framelength=1106
     
	{0x0000, 0x00, "eReadWrite",eTableEnd}
	
};
const IsiRegDescription_t Sensor_g_1920x1080_20fps[] =
{
	{0x0340, 0x07,"eReadWrite",eTableEnd},

	{0x0341, 0x42,"eReadWrite",eTableEnd},	//framelength=1660
      
	{0x0000, 0x00, "eReadWrite",eTableEnd}
	
};
const IsiRegDescription_t Sensor_g_1920x1080_15fps[] =
{
	{0x0340, 0x09,"eReadWrite",eTableEnd},

	{0x0341, 0xAc,"eReadWrite",eTableEnd},	//framelength=2212
    
  {0x0000, 0x00, "eReadWrite",eTableEnd}
	
};

const IsiRegDescription_t Sensor_g_1920x1080_10fps[] =
{
	{0x0340, 0x0E,"eReadWrite",eTableEnd},

	{0x0341, 0x82,"eReadWrite",eTableEnd},	//framelength=3318
      
	{0x0000, 0x00, "eReadWrite",eTableEnd}
	
};


