//GC2375_tables.c
/*****************************************************************************/
/*!
 *  \file        GC2375_tables.c \n
 *  \version     1.0 \n
 *  \author      henryHuang \n
 *  \brief       Image-sensor-specific tables for GC2375. \n
 *
 *  \revision    $Revision: 803 $ \n
 *               $Author: $ \n
 *               $Date: 2010-02-26 16:35:22 +0100 (Fr, 26 Feb 2010) $ \n
 *               $Id: OV13850_tables.c 803 2010-02-26 15:35:22Z  $ \n
 */
/*  SYNNEX TECHNOLOGY INTERNATIONAL CORP. for MiTAC COMPUTING
 */
/*****************************************************************************/
#include <ebase/types.h>
#include <ebase/trace.h>
#include <ebase/builtins.h>

#include <common/return_codes.h>

#include "isi.h"
#include "isi_iss.h"
#include "isi_priv.h"
#include "GC2375_MIPI_priv.h"


/*****************************************************************************
 * DEFINES
 *****************************************************************************/


/*****************************************************************************
 * GLOBALS
 *****************************************************************************/
// The settings may be altered by the code in IsiSetupSensor.

const IsiRegDescription_t Sensor_g_aRegDescription[] =
{
	{0xfe, 0x00, "eReadWrite",eReadWrite},
	{0xfe, 0x00, "eReadWrite",eReadWrite},
	{0xfe, 0x00, "eReadWrite",eReadWrite},
	{0xf7, 0x01, "eReadWrite",eReadWrite},	//PLL_mode1[0]:pll_en
	{0xf8, 0x0c, "eReadWrite",eReadWrite},	//PLL_mode2[5:0]:dicx4 eg:mclk 24 divx4=8 so pllclk_nodiv=24*8*4=768 for mipi
	{0xf9, 0x42, "eReadWrite",eReadWrite},	//analog_pwc	[6]:vpll_en , 
											//				[1]:lpldo_en
	{0xfa, 0x88, "eReadWrite",eReadWrite},	//clk_div_mode	[7]:div2_enable , 
											//				[3]:wclk_div2
	{0xfc, 0x8e, "eReadWrite",eReadWrite},	//cm_mode		[7]:regf_clk_enable , 
											//				[3]:isp_all_clock_enable ,
											//				[2]:serial_clk_en ,
											//				[1]:re_clock_pll
	{0xfe,0x00, "eReadWrite",eReadWrite},	//Reset related
	{0x88,0x03, "eReadWrite",eReadWrite},	//????????????
	{0x03,0x04, "eReadWrite",eReadWrite},	//exp_in_high	[5:0]exp_in
	{0x04,0x65, "eReadWrite",eReadWrite},	//exp_in_low	[7:0]exp_in (0x465=1125d)
	{0x05,0x02, "eReadWrite",eReadWrite},	//HB_high		[3:0]
	{0x06,0x5a, "eReadWrite",eReadWrite},	//HB_low		[7:0]	(0x25A=602d)
	{0x07,0x00, "eReadWrite",eReadWrite},	//VB_high		[4:0]
	{0x08,0x10, "eReadWrite",eReadWrite},	//VB_low		[7:0]	(0x10=16)
	{0x09,0x00, "eReadWrite",eReadWrite},	//Row_start_high[2:0]
	{0x0a,0x08, "eReadWrite",eReadWrite},	//Row_start_low	[7:0]	(0x08=8)
	{0x0b,0x00, "eReadWrite",eReadWrite},	//Col_start_high[2:0]
	{0x0c,0x18, "eReadWrite",eReadWrite},	//Col_start_low [7:0]	(0x18=24)
	{0x0d,0x04, "eReadWrite",eReadWrite},	//win_height_high[2:0]
	{0x0e,0xb8, "eReadWrite",eReadWrite},	//win_height_low[7:0]	(0x4B8=1208)
	{0x0f,0x06, "eReadWrite",eReadWrite},	//win_width_high[2:0]	
	{0x10,0x48, "eReadWrite",eReadWrite},	//win_width_low [7:0]	(0x648=1608)
	{0x17,0xd4, "eReadWrite",eReadWrite},	//CISCTL_mode1	[7:2]:reserved
											//				[1]:updown
											//				[0]:mirror
	{0x1c,0x10, "eReadWrite",eReadWrite},	//fifo2_push_prog_full_level [5:0] 
	{0x1d,0x13, "eReadWrite",eReadWrite},	//Sram_test_mode[3]:write_gate_mode
											//				[2]:read_gate_mode
											//				[1]:sram_gate
											//				[0]:sram_test
	{0x20,0x0b, "eReadWrite",eReadWrite},	//(p3)T_init_set	Timing of initial setting,more than 100us
	{0x21,0x6d, "eReadWrite",eReadWrite},	//(p3)T_LPX_set		Timing of LP setting,more than 50ns
	{0x22,0x0c, "eReadWrite",eReadWrite},	//(p3)T_CLK_HS_PREPARE_set
	{0x25,0xc1, "eReadWrite",eReadWrite},	//(p3)T_CLK_POST_set
	{0x26,0x0e, "eReadWrite",eReadWrite},	//(p3)T_CLK_TRIAL_set
	{0x27,0x22, "eReadWrite",eReadWrite},	//(p3)T_HS_Zero_set
	{0x29,0x5f, "eReadWrite",eReadWrite},	//(p3)T_HS_PREPARE_set
	{0x2b,0x88, "eReadWrite",eReadWrite},	//(p3)T_HS_TRIAL_set
	{0x2f,0x12, "eReadWrite",eReadWrite},	//??????????????
	{0x38,0x86, "eReadWrite",eReadWrite},	//??????????????
	{0x3d,0x00, "eReadWrite",eReadWrite},	//??????????????
	{0xcd,0xa3, "eReadWrite",eReadWrite},	//??????????????
	{0xce,0x57, "eReadWrite",eReadWrite},	//??????????????
	{0xd0,0x09, "eReadWrite",eReadWrite},	//??????????????
	{0xd1,0xca, "eReadWrite",eReadWrite},	//??????????????
	{0xd2,0x34, "eReadWrite",eReadWrite},	//??????????????
	{0xd3,0xbb, "eReadWrite",eReadWrite},	//??????????????
	{0xd8,0x60, "eReadWrite",eReadWrite},	//??????????????
	{0xe0,0x08, "eReadWrite",eReadWrite},	//??????????????
	{0xe1,0x1f, "eReadWrite",eReadWrite},	//??????????????
	{0xe4,0xf8, "eReadWrite",eReadWrite},	//??????????????
	{0xe5,0x0c, "eReadWrite",eReadWrite},	//??????????????
	{0xe6,0x10, "eReadWrite",eReadWrite},	//??????????????
	{0xe7,0xcc, "eReadWrite",eReadWrite},	//??????????????
	{0xe8,0x02, "eReadWrite",eReadWrite},	//??????????????
	{0xe9,0x01, "eReadWrite",eReadWrite},	//??????????????
	{0xea,0x02, "eReadWrite",eReadWrite},	//??????????????
	{0xeb,0x01, "eReadWrite",eReadWrite},	//??????????????
	{0x90,0x01, "eReadWrite",eReadWrite},	//win_mode_buf	[0]:crop_out_win_mode
	{0x92,0x02, "eReadWrite",eReadWrite},	//Crop_win_y1_low[7:0]
	{0x94,0x00, "eReadWrite",eReadWrite},	//Crop_win_x1_low[7:0]
	{0x95,0x04, "eReadWrite",eReadWrite},	//out_win_height_high[2:0]
	{0x96,0xb0, "eReadWrite",eReadWrite},	//out_win_height_low [7:0] (0x4B0=1200)
	{0x97,0x06, "eReadWrite",eReadWrite},	//out_win_width_high [2:0]
	{0x98,0x40, "eReadWrite",eReadWrite},	//out_win_width_low	 [7:0] (0x640=1600)
	{0x18,0x02, "eReadWrite",eReadWrite},	//CISCTL_mode2
	{0x1a,0x18, "eReadWrite",eReadWrite},	//??????????????
	{0x28,0x00, "eReadWrite",eReadWrite},	//T_wakeup_set
	{0x3f,0x40, "eReadWrite",eReadWrite},	//??????????????
	{0x40,0x26, "eReadWrite",eReadWrite},	//Blk_mode1 		[7:2]:Reserve
											//					[1]:dark_current_en
											//					[0]:offset_en
	{0x41,0x00, "eReadWrite",eReadWrite},	//??????????????
	{0x43,0x03, "eReadWrite",eReadWrite},	//Buf_win_width		[3:0]:Buf_win_width
	{0x4a,0x00, "eReadWrite",eReadWrite},	//??????????????
	{0x4e,0x3c, "eReadWrite",eReadWrite},	//??????????????
	{0x4f,0x00, "eReadWrite",eReadWrite},	//??????????????
	{0x66,0xc0, "eReadWrite",eReadWrite},	//??????????????
	{0x67,0x00, "eReadWrite",eReadWrite},	//??????????????
	{0x68,0x00, "eReadWrite",eReadWrite},	//??????????????
	{0xb0,0x58, "eReadWrite",eReadWrite},	//Global_gain_buf	[7:0]:Global_gain
	{0xb1,0x01, "eReadWrite",eReadWrite},	//Auto_pregain_high	[3:0]
	{0xb2,0x00, "eReadWrite",eReadWrite},	//Auto_pregain_low	[7:0]	(0x100=256)
	{0xb6,0x00, "eReadWrite",eReadWrite},	//gain_code			[3:0]
	{0xef,0x90, "eReadWrite",eReadWrite},	//??????????????
	{0xfe,0x03, "eReadWrite",eReadWrite},	//reset related		[2:0]page_select
	{0x01,0x03, "eReadWrite",eReadWrite},	//DPHY_analog_mode1	[1]:phy_lane0_en
											//					[0]:phy_clk_en
	{0x02,0x33, "eReadWrite",eReadWrite},	//DPHY_analog_mode2 [6:4]:lane0_diff
											//					[2:0]:clk_diff
	{0x03,0x90, "eReadWrite",eReadWrite},	//DPHY_analog_mode3	[7]:clklane_p2s_sel
											//					[4]:clk_delay
	{0x04,0x04, "eReadWrite",eReadWrite},	//FIFO_prog_full_level[7:0](LOW BYTE)
	{0x05,0x00, "eReadWrite",eReadWrite},	//FIFO_prog_full_level[0](HIGH BYTE)
	{0x06,0x80, "eReadWrite",eReadWrite},	//FIFO_mode
	{0x11,0x2b, "eReadWrite",eReadWrite},	//LDI_set	0x2a=RAW 8 ; 0x2b=RAW 10
	{0x12,0xd0, "eReadWrite",eReadWrite},	//LWX_set	RAW 8 : win_width
	{0x13,0x07, "eReadWrite",eReadWrite},	//			RAW 10:widthx5/4
	{0x15,0x00, "eReadWrite",eReadWrite},	//DPHY_mode
	{0x21,0x08, "eReadWrite",eReadWrite},	//T_LPX_set		Timing of LP setting,more than 50ns
	{0x22,0x05, "eReadWrite",eReadWrite},	//T_CLK_HS_PREPARE_set
	{0x23,0x13, "eReadWrite",eReadWrite},	//T_CLK_zero_set Timing of COCLK HS zero setting,more than 300ns
	{0x24,0x02, "eReadWrite",eReadWrite},	//T_CLK_PRE_set Timing of COCLK HS PRE of Data setting
	{0x25,0x13, "eReadWrite",eReadWrite},	//T_CLK_POST_set	Timing of COCLK HS Post of Data setting
	{0x26,0x08, "eReadWrite",eReadWrite},	//T_CLK_TRIAL_set	
	{0x29,0x06, "eReadWrite",eReadWrite},	//T_HS_PREPARE_set
	{0x2a,0x08, "eReadWrite",eReadWrite},	//T_HS_Zero_set
	{0x2b,0x08, "eReadWrite",eReadWrite},	//T_HS_TRAIL_s
	{0xfe,0x00, "eReadWrite",eReadWrite},	//
	{0x20,0x0b, "eReadWrite",eReadWrite},	//
	{0x22,0x0c, "eReadWrite",eReadWrite},	//
	{0x26,0x0e, "eReadWrite",eReadWrite},	//
	{0xb6,0x00, "eReadWrite",eReadWrite},	//gain_code


    {0x00 ,0x00, "eReadWrite",eTableEnd}
};
/*
const IsiRegDescription_t Sensor_g_svga[] =
{
	{0x3086, 0x01, "eReadWrite",eReadWrite},//PLL
	{0x3501, 0x26, "eReadWrite",eReadWrite},//exposure M
	{0x3502, 0x40, "eReadWrite",eReadWrite},//exposure L
	{0x3620, 0x26, "eReadWrite",eReadWrite},//analog control
	{0x3621, 0x37, "eReadWrite",eReadWrite},//
	{0x3622, 0x04, "eReadWrite",eReadWrite},//analog control
	{0x370a, 0x23, "eReadWrite",eReadWrite},//sennsor control
	{0x370d, 0xc0, "eReadWrite",eReadWrite},//
	{0x3718, 0x88, "eReadWrite",eReadWrite},//
	{0x3721, 0x00, "eReadWrite",eReadWrite},//
	{0x3722, 0x00, "eReadWrite",eReadWrite},//
	{0x3723, 0x00, "eReadWrite",eReadWrite},//
	{0x3738, 0x00, "eReadWrite",eReadWrite},// sennsor control
	{0x3803, 0x00, "eReadWrite",eReadWrite},// y start L
	{0x3807, 0xbf, "eReadWrite",eReadWrite},// y end L
	{0x3808, 0x03, "eReadWrite",eReadWrite},// x output size H
	{0x3809, 0x20, "eReadWrite",eReadWrite},// x output size L
	{0x380a, 0x02, "eReadWrite",eReadWrite},// y output size H
	{0x380b, 0x58, "eReadWrite",eReadWrite},// y output size L
	{0x380c, 0x06, "eReadWrite",eReadWrite},// HTS H
	{0x380d, 0xac, "eReadWrite",eReadWrite},// HTS L
	{0x380e, 0x02, "eReadWrite",eReadWrite},// VTS H
	{0x380f, 0x84, "eReadWrite",eReadWrite},// VTS L
	{0x3811, 0x04, "eReadWrite",eReadWrite},// ISP x win L
	{0x3813, 0x04, "eReadWrite",eReadWrite},// ISP y win L
	{0x3814, 0x31, "eReadWrite",eReadWrite},// x inc
	{0x3815, 0x31, "eReadWrite",eReadWrite},// y inc
	{0x3820, 0xc2, "eReadWrite",eReadWrite},// vsun48_blc, vflip_blc, vbinf
	{0x3821, 0x01, "eReadWrite",eReadWrite},// hbin
	{0x4008, 0x00, "eReadWrite",eReadWrite},// blc_start
	{0x4009, 0x03, "eReadWrite",eReadWrite},// blc_end
	{0x4837, 0x30, "eReadWrite",eReadWrite},// MIPI global timing
	
    {0x0000, 0x00,"eReadWrite",eReadWrite}
};
*/

const IsiRegDescription_t Sensor_g_1600x1200[] =
{

/*
#if 1
	{0x3086, 0x00, "eReadWrite",eReadWrite},//PLL
	//{0x3501, 0x4e, "eReadWrite",eReadWrite},//exposure M
	//{0x3502, 0xe0, "eReadWrite",eReadWrite},//exposure L
	{0x3620, 0x26, "eReadWrite",eReadWrite},// analog control
	{0x3621, 0x37, "eReadWrite",eReadWrite},//
	{0x3622, 0x04, "eReadWrite",eReadWrite},// analog control
	{0x370a, 0x21, "eReadWrite",eReadWrite},// sennsor control
	{0x370d, 0xc0, "eReadWrite",eReadWrite},//
	{0x3718, 0x88, "eReadWrite",eReadWrite},//
	{0x3721, 0x00, "eReadWrite",eReadWrite},//
	{0x3722, 0x00, "eReadWrite",eReadWrite},//
	{0x3723, 0x00, "eReadWrite",eReadWrite},//
	{0x3738, 0x00, "eReadWrite",eReadWrite},// sennsor control
	{0x3803, 0x00, "eReadWrite",eReadWrite},// y start L
	{0x3807, 0xbf, "eReadWrite",eReadWrite},// y end L
	{0x3808, 0x06, "eReadWrite",eReadWrite},// x output size H
	{0x3809, 0x40, "eReadWrite",eReadWrite},// x output size L
	{0x380a, 0x04, "eReadWrite",eReadWrite},// y output size H
	{0x380b, 0xb0, "eReadWrite",eReadWrite},// y output size L
	{0x380c, 0x06, "eReadWrite",eReadWrite},// HTS H
	{0x380d, 0xa4, "eReadWrite",eReadWrite},// HTS L
	{0x380e, 0x05, "eReadWrite",eReadWrite},// VTS H
	{0x380f, 0x0e, "eReadWrite",eReadWrite},// VTS L
	{0x3811, 0x08, "eReadWrite",eReadWrite},// ISP x win L
	{0x3813, 0x08, "eReadWrite",eReadWrite},// ISP y win L
	{0x3814, 0x11, "eReadWrite",eReadWrite},// x inc
	{0x3815, 0x11, "eReadWrite",eReadWrite},// y inc
	{0x3820, 0xc0, "eReadWrite",eReadWrite},// vsun48_blc, vflip_blc, vbin off
	{0x3821, 0x00, "eReadWrite",eReadWrite},// hbin off
	{0x4008, 0x02, "eReadWrite",eReadWrite},// blc_start
	{0x4009, 0x09, "eReadWrite",eReadWrite},// blc_end
	{0x4837, 0x18, "eReadWrite",eReadWrite},// MIPI global timing
#else
	// sysclk = 33Mhz, MIPI data rate 330Mbps
	{0x3086, 0x01, "eReadWrite",eReadWrite}, // PLL
	{0x3501, 0x4e, "eReadWrite",eReadWrite}, // exposure M
	{0x3502, 0xe0, "eReadWrite",eReadWrite}, // exposure L
	{0x3620, 0x24, "eReadWrite",eReadWrite}, // analog control
	{0x3621, 0x34, "eReadWrite",eReadWrite}, //
	{0x3622, 0x03, "eReadWrite",eReadWrite}, // analog control
	{0x370a, 0x21, "eReadWrite",eReadWrite}, //
	{0x370d, 0x00, "eReadWrite",eReadWrite}, //
	{0x3718, 0x80, "eReadWrite",eReadWrite}, //
	{0x3721, 0x09, "eReadWrite",eReadWrite}, //
	{0x3722, 0x0b, "eReadWrite",eReadWrite}, //
	{0x3723, 0x48, "eReadWrite",eReadWrite}, //
	{0x3738, 0x99, "eReadWrite",eReadWrite}, // sennsor control
	{0x3803, 0x00, "eReadWrite",eReadWrite}, // y start L
	{0x3807, 0xbf, "eReadWrite",eReadWrite}, // y end L
	{0x3808, 0x06, "eReadWrite",eReadWrite}, // x output size H
	{0x3809, 0x40, "eReadWrite",eReadWrite}, // x output size L
	{0x380a, 0x04, "eReadWrite",eReadWrite}, // y output size H
	{0x380b, 0xb0, "eReadWrite",eReadWrite}, // y output size H
	{0x380c, 0x06, "eReadWrite",eReadWrite}, // HTS H
	{0x380d, 0xa4, "eReadWrite",eReadWrite}, // HTS L
	{0x380e, 0x05, "eReadWrite",eReadWrite}, // VTS H
	{0x380f, 0x0e, "eReadWrite",eReadWrite}, // VTS L
	{0x3811, 0x08, "eReadWrite",eReadWrite}, // ISP x win L
	{0x3813, 0x08, "eReadWrite",eReadWrite}, // ISP y win L
	{0x3814, 0x11, "eReadWrite",eReadWrite}, // x inc
	{0x3815, 0x11, "eReadWrite",eReadWrite}, // y inc
	{0x3820, 0xc0, "eReadWrite",eReadWrite}, // vsun48_blc, vflip_blc, vbin off
	{0x3821, 0x00, "eReadWrite",eReadWrite}, // hbin off
	{0x4008, 0x02, "eReadWrite",eReadWrite}, // blc_start
	{0x4009, 0x09, "eReadWrite",eReadWrite}, // blc_end
	{0x4837, 0x30, "eReadWrite",eReadWrite}, // MIPI global timing
#endif
*/
    {0x00, 0x00,"eReadWrite",eTableEnd}
};

const IsiRegDescription_t Sensor_g_1600x1200_30fps[] =
{
    {0xfe, 0x00, "eReadWrite",eReadWrite},
	{0x03, 0x04, "eReadWrite",eReadWrite},// VTS H
	{0x04, 0xD8, "eReadWrite",eReadWrite},// VTS L
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};
const IsiRegDescription_t Sensor_g_1600x1200_20fps[] =
{
    {0xfe, 0x00, "eReadWrite",eReadWrite},
	{0x03, 0x07, "eReadWrite",eReadWrite},// VTS H
	{0x04, 0x44, "eReadWrite",eReadWrite},// VTS L
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};
const IsiRegDescription_t Sensor_g_1600x1200_15fps[] =
{
    {0xfe, 0x00, "eReadWrite",eReadWrite},
	{0x03, 0x09, "eReadWrite",eReadWrite},// VTS H
	{0x04, 0xb0, "eReadWrite",eReadWrite},// VTS L
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};

const IsiRegDescription_t Sensor_g_1600x1200_10fps[] =
{
    {0xfe, 0x00, "eReadWrite",eReadWrite},
	{0x03, 0x0e, "eReadWrite",eReadWrite},// VTS H
	{0x04, 0x88, "eReadWrite",eReadWrite},// VTS L
	{0x0000 ,0x00,"eTableEnd",eTableEnd}
};


